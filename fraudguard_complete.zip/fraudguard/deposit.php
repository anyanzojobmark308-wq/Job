<?php
// ============================================================
//  FraudGuard – Customer Deposit Page (deposit.php)
//  Save this file as: C:\xampp\htdocs\fraudguard\deposit.php
// ============================================================
require_once 'php/config.php';
startSession();
requireLogin();
$user = currentUser();
if (isAdmin()) { header('Location: admin_deposits.php'); exit; }
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Deposit Money – FraudGuard</title>
<link href="https://fonts.googleapis.com/css2?family=Space+Grotesk:wght@300;400;500;600;700&family=Syne:wght@700;800&display=swap" rel="stylesheet">
<link rel="stylesheet" href="css/style.css">
<style>
.method-card {
  padding: 14px 16px;
  background: var(--surface2);
  border: 1px solid var(--border);
  border-radius: 12px;
  margin-bottom: 10px;
  cursor: pointer;
  transition: all .2s;
  display: flex;
  align-items: center;
  gap: 14px;
}
.method-card:hover { border-color: var(--accent); }
.method-card.selected { border-color: var(--accent); background: rgba(0,212,255,0.06); }
.method-icon { font-size: 24px; width: 36px; text-align: center; }
.method-name { font-size: 14px; font-weight: 600; }
.method-detail { font-size: 12px; color: var(--muted); margin-top: 2px; }
.method-radio { margin-left: auto; }
.quick-btn {
  padding: 8px 16px;
  background: var(--surface2);
  border: 1px solid var(--border);
  border-radius: 8px;
  color: var(--text);
  font-family: 'Space Grotesk', sans-serif;
  font-size: 13px;
  font-weight: 600;
  cursor: pointer;
  transition: all .2s;
}
.quick-btn:hover { border-color: var(--accent); color: var(--accent); }
.instruction-box {
  background: rgba(0,212,255,0.05);
  border: 1px solid rgba(0,212,255,0.2);
  border-radius: 12px;
  padding: 16px;
  margin: 14px 0;
  font-size: 13px;
  line-height: 1.9;
  display: none;
}
.instruction-box.show { display: block; }
.step-row { display: flex; align-items: flex-start; gap: 10px; margin-bottom: 6px; }
.step-num {
  min-width: 22px; height: 22px;
  background: var(--accent);
  color: #000;
  border-radius: 50%;
  font-size: 11px;
  font-weight: 700;
  display: flex; align-items: center; justify-content: center;
  flex-shrink: 0;
  margin-top: 1px;
}
.send-to {
  background: var(--surface);
  border: 1px solid var(--border);
  border-radius: 8px;
  padding: 10px 14px;
  font-family: monospace;
  font-size: 15px;
  color: var(--accent);
  font-weight: 700;
  margin: 6px 0;
  text-align: center;
  letter-spacing: 1px;
}
</style>
</head>
<body>
<div class="app-layout">

  <!-- ── SIDEBAR ─────────────────────────────────────── -->
  <aside class="sidebar">
    <div class="sidebar-brand">
      <div class="icon">🛡️</div>
      <div class="name">Fraud<span>Guard</span></div>
    </div>
    <div class="sidebar-user">
      <div class="avatar"><?= strtoupper(substr($user['full_name'],0,1)) ?></div>
      <div class="uname"><?= htmlspecialchars($user['full_name']) ?></div>
      <div class="urole"><?= ucfirst($user['role']) ?></div>
    </div>
    <nav class="sidebar-nav">
      <div class="nav-section-title">Main</div>
      <a href="dashboard.php"   class="nav-link"><span class="icon">📊</span> Dashboard</a>
      <a href="deposit.php"     class="nav-link active"><span class="icon">💰</span> Deposit Money</a>
      <a href="transactions.php" class="nav-link"><span class="icon">📋</span> Transactions</a>
      <div class="nav-section-title">Support</div>
      <a href="refunds.php"        class="nav-link"><span class="icon">🔄</span> Refund Cases</a>
      <a href="notifications.php"  class="nav-link"><span class="icon">🔔</span> Notifications</a>
    </nav>
    <div class="sidebar-footer">
      <a href="php/auth.php?action=logout" class="nav-link"><span class="icon">🚪</span> Logout</a>
    </div>
  </aside>

  <!-- ── MAIN ────────────────────────────────────────── -->
  <div class="main-content">
    <div class="topbar">
      <div class="topbar-title">💰 Deposit Money</div>
      <div class="topbar-actions">
        <div style="font-size:14px; color:var(--muted)">
          Balance: <strong style="color:var(--accent)" id="topbar-balance">Loading...</strong>
        </div>
      </div>
    </div>

    <div class="page-content">
      <div id="toast-container"></div>

      <div class="grid-2" style="align-items:start">

        <!-- ── LEFT: Deposit Form ─────────────────────── -->
        <div>

          <!-- Balance Card -->
          <div class="data-card" style="margin-bottom:20px">
            <div style="padding:24px; text-align:center">
              <div style="font-size:12px; color:var(--muted); text-transform:uppercase; letter-spacing:1px; margin-bottom:8px">
                Your Current Balance
              </div>
              <div style="font-size:38px; font-weight:700; color:var(--white)" id="balance-display">—</div>
              <div style="font-size:13px; color:var(--muted); margin-top:6px" id="account-no-display"></div>

              <!-- Quick amount buttons -->
              <div style="margin-top:20px; display:flex; gap:8px; justify-content:center; flex-wrap:wrap">
                <button class="quick-btn" onclick="setAmount(100000)">100K</button>
                <button class="quick-btn" onclick="setAmount(500000)">500K</button>
                <button class="quick-btn" onclick="setAmount(1000000)">1M</button>
                <button class="quick-btn" onclick="setAmount(2000000)">2M</button>
                <button class="quick-btn" onclick="setAmount(5000000)">5M</button>
              </div>
            </div>
          </div>

          <!-- Deposit Request Form -->
          <div class="data-card">
            <div class="data-card-header">
              <div class="data-card-title">📥 New Deposit Request</div>
            </div>
            <div style="padding:22px">

              <!-- How it works notice -->
              <div style="background:rgba(0,212,255,0.06); border:1px solid rgba(0,212,255,0.15); border-radius:10px; padding:14px; margin-bottom:22px; font-size:13px; line-height:1.8">
                <div style="font-weight:600; color:var(--accent); margin-bottom:6px">📋 How it works</div>
                <div style="color:var(--muted)">
                  1. Choose amount and payment method below<br>
                  2. Send the money using the payment details shown<br>
                  3. Enter your payment reference number<br>
                  4. Submit — admin verifies and credits your account ✅
                </div>
              </div>

              <div id="form-alert"></div>

              <!-- Amount -->
              <div class="form-group">
                <label class="form-label">Amount to Deposit (UGX)</label>
                <input type="number" class="form-input" id="dep-amount"
                  placeholder="Enter amount e.g. 500000"
                  min="1000" oninput="updateAmountPreview()">
                <div id="amount-preview" style="font-size:12px; margin-top:6px; color:var(--muted)"></div>
              </div>

              <!-- Payment Method -->
              <div class="form-group">
                <label class="form-label">Choose Payment Method</label>

                <div class="method-card" id="mc-mtn" onclick="selectMethod('MTN Mobile Money','mc-mtn')">
                  <div class="method-icon">📱</div>
                  <div>
                    <div class="method-name" style="color:#FFB300">MTN Mobile Money</div>
                    <div class="method-detail">Dial *165# → Send Money</div>
                  </div>
                  <input type="radio" name="method" value="MTN Mobile Money" class="method-radio">
                </div>

                <div class="method-card" id="mc-airtel" onclick="selectMethod('Airtel Money','mc-airtel')">
                  <div class="method-icon">📱</div>
                  <div>
                    <div class="method-name" style="color:#E53935">Airtel Money</div>
                    <div class="method-detail">Dial *185# → Send Money</div>
                  </div>
                  <input type="radio" name="method" value="Airtel Money" class="method-radio">
                </div>

                <div class="method-card" id="mc-bank" onclick="selectMethod('Bank Transfer','mc-bank')">
                  <div class="method-icon">🏦</div>
                  <div>
                    <div class="method-name" style="color:var(--accent)">Bank Transfer</div>
                    <div class="method-detail">Stanbic Bank — Account 9030012345678</div>
                  </div>
                  <input type="radio" name="method" value="Bank Transfer" class="method-radio">
                </div>

                <div class="method-card" id="mc-cash" onclick="selectMethod('Cash Deposit','mc-cash')">
                  <div class="method-icon">🏪</div>
                  <div>
                    <div class="method-name" style="color:var(--success)">Cash Deposit (Agent)</div>
                    <div class="method-detail">Visit any FraudGuard agent near you</div>
                  </div>
                  <input type="radio" name="method" value="Cash Deposit" class="method-radio">
                </div>
              </div>

              <!-- Dynamic payment instructions -->
              <div class="instruction-box" id="instr-mtn">
                <div style="font-weight:600; color:#FFB300; margin-bottom:10px">📱 MTN Mobile Money Steps</div>
                <div class="step-row"><div class="step-num">1</div><div>Pick up your phone and dial <strong>*165#</strong></div></div>
                <div class="step-row"><div class="step-num">2</div><div>Select option <strong>1 – Send Money</strong></div></div>
                <div class="step-row"><div class="step-num">3</div><div>Enter this number:</div></div>
                <div class="send-to">0700 000 001</div>
                <div class="step-row"><div class="step-num">4</div><div>Enter the amount you typed above</div></div>
                <div class="step-row"><div class="step-num">5</div><div>Confirm with your MTN PIN</div></div>
                <div class="step-row"><div class="step-num">6</div><div>You will receive an <strong>SMS with a transaction ID</strong> — copy it and paste in the field below</div></div>
              </div>

              <div class="instruction-box" id="instr-airtel">
                <div style="font-weight:600; color:#E53935; margin-bottom:10px">📱 Airtel Money Steps</div>
                <div class="step-row"><div class="step-num">1</div><div>Pick up your phone and dial <strong>*185#</strong></div></div>
                <div class="step-row"><div class="step-num">2</div><div>Select option <strong>1 – Send Money</strong></div></div>
                <div class="step-row"><div class="step-num">3</div><div>Enter this number:</div></div>
                <div class="send-to">0752 000 001</div>
                <div class="step-row"><div class="step-num">4</div><div>Enter the amount you typed above</div></div>
                <div class="step-row"><div class="step-num">5</div><div>Confirm with your Airtel PIN</div></div>
                <div class="step-row"><div class="step-num">6</div><div>Copy the <strong>transaction ID from the SMS</strong> you receive</div></div>
              </div>

              <div class="instruction-box" id="instr-bank">
                <div style="font-weight:600; color:var(--accent); margin-bottom:10px">🏦 Bank Transfer Details</div>
                <div class="step-row"><div class="step-num">1</div><div>Login to your mobile banking app or visit a bank branch</div></div>
                <div class="step-row"><div class="step-num">2</div><div>Transfer to this account:</div></div>
                <div class="send-to">Stanbic Bank<br>Acc: 9030012345678<br>Name: FraudGuard Uganda</div>
                <div class="step-row"><div class="step-num">3</div><div>Use your FraudGuard account number as the payment reference</div></div>
                <div class="step-row"><div class="step-num">4</div><div>Save your bank <strong>transaction reference number</strong></div></div>
              </div>

              <div class="instruction-box" id="instr-cash">
                <div style="font-weight:600; color:var(--success); margin-bottom:10px">🏪 Cash Deposit (Agent) Steps</div>
                <div class="step-row"><div class="step-num">1</div><div>Visit any FraudGuard agent near you</div></div>
                <div class="step-row"><div class="step-num">2</div><div>Tell the agent your account number:</div></div>
                <div class="send-to" id="agent-acc-display">Loading...</div>
                <div class="step-row"><div class="step-num">3</div><div>Hand over the cash amount</div></div>
                <div class="step-row"><div class="step-num">4</div><div>The agent gives you a <strong>receipt with a reference number</strong> — enter it below</div></div>
              </div>

              <!-- Payment Reference -->
              <div class="form-group">
                <label class="form-label">Your Payment Reference / Transaction ID</label>
                <input type="text" class="form-input" id="dep-ref"
                  placeholder="e.g. MTN2026123456789 or STANBIC-REF-001">
                <div style="font-size:12px; color:var(--muted); margin-top:6px">
                  This is the reference number from your mobile money SMS or bank receipt.
                  The admin uses this to verify your payment.
                </div>
              </div>

              <!-- Notes -->
              <div class="form-group">
                <label class="form-label">Additional Notes <span style="color:var(--muted); font-weight:400">(optional)</span></label>
                <textarea class="form-textarea" id="dep-notes"
                  placeholder="Any extra info for the admin e.g. I sent from 0701234567"
                  style="min-height:70px"></textarea>
              </div>

              <!-- Submit Button -->
              <button class="btn btn-primary" id="dep-submit-btn"
                onclick="submitDeposit()" style="width:100%; padding:14px; font-size:15px">
                💰 Submit Deposit Request
              </button>

            </div>
          </div>
        </div>

        <!-- ── RIGHT: Deposit History ──────────────────── -->
        <div>
          <div class="data-card">
            <div class="data-card-header">
              <div class="data-card-title">📜 My Deposit History</div>
              <button class="btn btn-secondary btn-sm" onclick="loadHistory()">🔄 Refresh</button>
            </div>
            <div id="history-area">
              <div style="text-align:center; padding:40px; color:var(--muted)">Loading...</div>
            </div>
          </div>
        </div>

      </div>
    </div>
  </div>
</div>

<script>
// ── Helpers ───────────────────────────────────────────────
function fmtUGX(n) {
  return 'UGX ' + Number(n).toLocaleString();
}
function fmtDate(s) {
  return new Date(s).toLocaleString('en-UG', {
    day: '2-digit', month: 'short', year: 'numeric',
    hour: '2-digit', minute: '2-digit'
  });
}
function toast(msg, type = 'success') {
  const t = document.createElement('div');
  t.className = `toast toast-${type}`;
  t.textContent = msg;
  document.getElementById('toast-container').appendChild(t);
  setTimeout(() => t.remove(), 5000);
}

let selectedMethod = '';

// ── Set quick amount ─────────────────────────────────────
function setAmount(val) {
  document.getElementById('dep-amount').value = val;
  updateAmountPreview();
}

// ── Preview amount ───────────────────────────────────────
function updateAmountPreview() {
  const val = parseFloat(document.getElementById('dep-amount').value);
  const el  = document.getElementById('amount-preview');
  if (val >= 1000) {
    el.innerHTML = `<span style="color:var(--success)">✅ ${fmtUGX(val)} will be credited after admin approval</span>`;
  } else if (val > 0) {
    el.innerHTML = `<span style="color:var(--danger)">⚠️ Minimum deposit is UGX 1,000</span>`;
  } else {
    el.textContent = '';
  }
}

// ── Select payment method ─────────────────────────────────
function selectMethod(method, cardId) {
  selectedMethod = method;

  // Remove selected from all cards
  document.querySelectorAll('.method-card').forEach(c => c.classList.remove('selected'));
  document.querySelectorAll('.instruction-box').forEach(b => b.classList.remove('show'));

  // Select clicked card
  document.getElementById(cardId).classList.add('selected');

  // Check the radio inside
  const radio = document.querySelector(`#${cardId} input[type=radio]`);
  if (radio) radio.checked = true;

  // Show matching instructions
  const map = {
    'MTN Mobile Money': 'instr-mtn',
    'Airtel Money':     'instr-airtel',
    'Bank Transfer':    'instr-bank',
    'Cash Deposit':     'instr-cash'
  };
  if (map[method]) {
    document.getElementById(map[method]).classList.add('show');
  }
}

// ── Load balance from dashboard stats ─────────────────────
async function loadBalance() {
  const res  = await fetch('php/analytics.php?action=dashboard_stats');
  const json = await res.json();
  if (!json.success) return;
  const d = json.data;

  document.getElementById('balance-display').textContent    = fmtUGX(d.balance);
  document.getElementById('topbar-balance').textContent     = fmtUGX(d.balance);
  document.getElementById('account-no-display').textContent = 'Account: ' + (d.account_no || '—');

  const agentEl = document.getElementById('agent-acc-display');
  if (agentEl) agentEl.textContent = d.account_no || '—';
}

// ── Load deposit history ──────────────────────────────────
async function loadHistory() {
  const area = document.getElementById('history-area');
  area.innerHTML = '<div style="text-align:center;padding:30px;color:var(--muted)">Loading...</div>';

  const res  = await fetch('php/deposit.php?action=my_deposits');
  const json = await res.json();

  if (!json.success || !json.data.length) {
    area.innerHTML = `
      <div class="empty-state" style="padding:50px 20px">
        <div class="icon">💰</div>
        <p>No deposit requests yet.<br>Use the form on the left to make your first deposit.</p>
      </div>`;
    return;
  }

  const rows = json.data.map(d => {
    const statusClass = d.status === 'approved' ? 'completed'
                      : d.status === 'rejected' ? 'blocked' : 'pending';
    const statusIcon  = d.status === 'approved' ? '✅'
                      : d.status === 'rejected' ? '❌' : '⏳';
    return `
      <div style="padding:16px 20px; border-bottom:1px solid var(--border)">
        <div style="display:flex; justify-content:space-between; align-items:start; margin-bottom:8px">
          <div>
            <span style="font-family:monospace; color:var(--accent); font-size:12px">
              ${d.deposit_reference}
            </span>
            <span class="badge badge-${statusClass}" style="margin-left:8px">
              ${statusIcon} ${d.status.charAt(0).toUpperCase() + d.status.slice(1)}
            </span>
          </div>
          <div style="text-align:right; font-size:12px; color:var(--muted)">${fmtDate(d.created_at)}</div>
        </div>

        <div style="display:flex; justify-content:space-between; align-items:center">
          <div>
            <div style="font-size:13px; color:var(--muted)">${d.payment_method}</div>
            <div style="font-weight:700; font-size:16px; color:var(--warning); margin-top:2px">
              ${fmtUGX(d.amount)} requested
            </div>
            ${d.amount_approved > 0
              ? `<div style="font-size:13px; color:var(--success); margin-top:2px">
                   ✅ ${fmtUGX(d.amount_approved)} credited
                 </div>`
              : ''}
          </div>
          <div style="text-align:right; font-size:12px; color:var(--muted); max-width:160px">
            ${d.payment_ref
              ? `<div>Ref: <span style="font-family:monospace">${d.payment_ref}</span></div>`
              : ''}
            ${d.admin_notes
              ? `<div style="margin-top:4px; color:${d.status==='rejected'?'var(--danger)':'var(--muted)'}">
                   ${d.admin_notes}
                 </div>`
              : ''}
          </div>
        </div>
      </div>`;
  }).join('');

  area.innerHTML = rows;
}

// ── Submit deposit request ────────────────────────────────
async function submitDeposit() {
  const amount  = document.getElementById('dep-amount').value;
  const ref     = document.getElementById('dep-ref').value.trim();
  const notes   = document.getElementById('dep-notes').value.trim();
  const alertEl = document.getElementById('form-alert');
  const btn     = document.getElementById('dep-submit-btn');

  // Validate
  if (!amount || parseFloat(amount) < 1000) {
    alertEl.innerHTML = '<div class="alert alert-error">⚠️ Please enter an amount of at least UGX 1,000.</div>';
    return;
  }
  if (!selectedMethod) {
    alertEl.innerHTML = '<div class="alert alert-error">⚠️ Please select a payment method by clicking one of the cards above.</div>';
    return;
  }
  if (!ref) {
    alertEl.innerHTML = '<div class="alert alert-error">⚠️ Please enter your payment reference number from your mobile money SMS or bank receipt.</div>';
    return;
  }

  alertEl.innerHTML = '';
  btn.innerHTML     = '<div class="spinner"></div>&nbsp; Submitting...';
  btn.disabled      = true;

  const body = new FormData();
  body.append('action',       'request_deposit');
  body.append('amount',       amount);
  body.append('method',       selectedMethod);
  body.append('payment_ref',  ref);
  body.append('notes',        notes);

  try {
    const res  = await fetch('php/deposit.php', { method: 'POST', body });
    const json = await res.json();

    if (json.success) {
      alertEl.innerHTML = `
        <div class="alert alert-success">
          ✅ ${json.message}
        </div>`;

      // Clear the form
      document.getElementById('dep-amount').value = '';
      document.getElementById('dep-ref').value    = '';
      document.getElementById('dep-notes').value  = '';
      document.getElementById('amount-preview').textContent = '';
      document.querySelectorAll('.method-card').forEach(c => c.classList.remove('selected'));
      document.querySelectorAll('.instruction-box').forEach(b => b.classList.remove('show'));
      document.querySelectorAll('input[name=method]').forEach(r => r.checked = false);
      selectedMethod = '';

      // Reload history
      loadHistory();

      toast('Deposit request submitted! Waiting for admin approval.', 'success');

    } else {
      alertEl.innerHTML = `<div class="alert alert-error">⚠️ ${json.message}</div>`;
    }

  } catch (err) {
    alertEl.innerHTML = '<div class="alert alert-error">⚠️ Network error. Please try again.</div>';
  }

  btn.innerHTML = '💰 Submit Deposit Request';
  btn.disabled  = false;
}

// ── Init ─────────────────────────────────────────────────
loadBalance();
loadHistory();
</script>
</body>
</html>
