<?php
// ============================================================
//  FraudGuard – My Refund Cases (Customer)
// ============================================================
require_once 'php/config.php';
startSession(); requireLogin();
$user = currentUser();
if (isAdmin()) { header('Location: admin_cases.php'); exit; }
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>My Refund Cases – FraudGuard</title>
<link href="https://fonts.googleapis.com/css2?family=Space+Grotesk:wght@300;400;500;600;700&family=Syne:wght@700;800&display=swap" rel="stylesheet">
<link rel="stylesheet" href="css/style.css">
</head>
<body>
<div class="app-layout">
  <aside class="sidebar">
    <div class="sidebar-brand"><div class="icon">🛡️</div><div class="name">Fraud<span>Guard</span></div></div>
    <div class="sidebar-user">
      <div class="avatar"><?= strtoupper(substr($user['full_name'],0,1)) ?></div>
      <div class="uname"><?= htmlspecialchars($user['full_name']) ?></div>
      <div class="urole"><?= ucfirst($user['role']) ?></div>
    </div>
    <nav class="sidebar-nav">
      <a href="dashboard.php" class="nav-link"><span class="icon">📊</span> Dashboard</a>
      <a href="transactions.php" class="nav-link"><span class="icon">📋</span> Transactions</a>
      <a href="refunds.php" class="nav-link active"><span class="icon">🔄</span> My Refund Cases</a>
      <a href="notifications.php" class="nav-link"><span class="icon">🔔</span> Notifications</a>
    </nav>
    <div class="sidebar-footer"><a href="php/auth.php?action=logout" class="nav-link"><span class="icon">🚪</span> Logout</a></div>
  </aside>

  <div class="main-content">
    <div class="topbar">
      <div class="topbar-title">My Refund Cases</div>
      <div class="topbar-actions">
        <button class="btn btn-primary" onclick="openModal('refundModal')">+ Report Fraud</button>
      </div>
    </div>
    <div class="page-content">
      <div id="toast-container"></div>
      <div class="data-card">
        <div class="data-card-header"><div class="data-card-title">📁 Refund & Dispute Cases</div></div>
        <div style="overflow-x:auto">
          <table class="data-table">
            <thead><tr>
              <th>Case Reference</th><th>Transaction</th><th>Fraud Type</th>
              <th>Amount Claimed</th><th>Amount Approved</th><th>Priority</th>
              <th>Status</th><th>Submitted</th>
            </tr></thead>
            <tbody id="cases-body">
              <tr><td colspan="8" style="text-align:center;color:var(--muted);padding:30px">Loading...</td></tr>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  </div>
</div>

<!-- Report Modal -->
<div class="modal-overlay" id="refundModal">
  <div class="modal">
    <div style="display:flex;justify-content:space-between;align-items:start;margin-bottom:20px">
      <div><div class="modal-title">📝 Report Fraud</div><div class="modal-sub">Request a refund for an unauthorized transaction</div></div>
      <button onclick="closeModal('refundModal')" style="background:none;border:none;color:var(--muted);font-size:22px;cursor:pointer">×</button>
    </div>
    <div id="refund-alert"></div>
    <div class="form-group"><label class="form-label">Transaction Reference</label><input type="text" class="form-input" id="case-txn-ref" placeholder="TXN-2025-XXXXXX"></div>
    <div class="form-group"><label class="form-label">Fraud Type</label>
      <select class="form-select" id="case-fraud-type">
        <option>Unauthorized Transfer</option>
        <option>SIM Swap Fraud</option>
        <option>Phishing/Scam</option>
        <option>Account Takeover</option>
        <option>Fake Payment Confirmation</option>
        <option>Other</option>
      </select>
    </div>
    <div class="form-group"><label class="form-label">Amount Claimed (UGX)</label><input type="number" class="form-input" id="case-amount"></div>
    <div class="form-group"><label class="form-label">Description</label><textarea class="form-textarea" id="case-desc" placeholder="Describe what happened..."></textarea></div>
    <div style="display:flex;gap:12px">
      <button class="btn btn-secondary" onclick="closeModal('refundModal')" style="flex:1">Cancel</button>
      <button class="btn btn-primary" onclick="submitCase()" style="flex:1">Submit Case</button>
    </div>
  </div>
</div>

<script>
function openModal(id)  { document.getElementById(id).classList.add('open'); }
function closeModal(id) { document.getElementById(id).classList.remove('open'); }
function fmtUGX(n) { return 'UGX ' + Number(n).toLocaleString(); }
function fmtDate(s) { return new Date(s).toLocaleDateString('en-UG',{day:'2-digit',month:'short',year:'numeric'}); }

async function loadCases() {
  const res  = await fetch('php/refund.php?action=get_my_cases');
  const json = await res.json();
  if (!json.success) return;
  const tbody = document.getElementById('cases-body');
  if (!json.data.length) {
    tbody.innerHTML = '<tr><td colspan="8" style="text-align:center;color:var(--muted);padding:40px"><div class="empty-state"><div class="icon">📁</div><p>No refund cases yet. Report fraud using the button above.</p></div></td></tr>';
    return;
  }
  tbody.innerHTML = json.data.map(c => `
    <tr>
      <td><span style="font-family:monospace;color:var(--accent);font-size:12px">${c.case_reference}</span></td>
      <td style="font-family:monospace;font-size:12px;color:var(--muted)">${c.txn_reference}</td>
      <td>${c.fraud_type}</td>
      <td style="color:var(--warning);font-weight:600">${fmtUGX(c.amount_claimed)}</td>
      <td style="color:${c.amount_approved>0 ? 'var(--success)' : 'var(--muted)'}">
        ${c.amount_approved > 0 ? fmtUGX(c.amount_approved) : '—'}
      </td>
      <td><span class="badge badge-${c.priority}">${c.priority}</span></td>
      <td><span class="badge badge-${c.status}">${c.status.replace('_',' ')}</span></td>
      <td style="color:var(--muted);font-size:12px">${fmtDate(c.submitted_at)}</td>
    </tr>
  `).join('');
}

async function submitCase() {
  const body = new FormData();
  body.append('action',         'submit_case');
  body.append('txn_reference',  document.getElementById('case-txn-ref').value);
  body.append('fraud_type',     document.getElementById('case-fraud-type').value);
  body.append('amount_claimed', document.getElementById('case-amount').value);
  body.append('description',    document.getElementById('case-desc').value);
  const res  = await fetch('php/refund.php', { method:'POST', body });
  const json = await res.json();
  const el   = document.getElementById('refund-alert');
  if (json.success) {
    el.innerHTML = `<div class="alert alert-success">✅ ${json.message}</div>`;
    setTimeout(() => { closeModal('refundModal'); loadCases(); }, 2000);
  } else {
    el.innerHTML = `<div class="alert alert-error">⚠️ ${json.message}</div>`;
  }
}

loadCases();
</script>
</body>
</html>
