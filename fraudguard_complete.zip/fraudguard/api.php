<?php
// ============================================================
//  FraudGuard – Public REST API (api.php)
//  Base URL: http://localhost/fraudguard/api.php
//
//  Authentication: Pass API key in header:
//    X-API-Key: your_api_key_here
//
//  All responses are JSON.
// ============================================================
require_once 'php/config.php';

// ─── CORS Headers (allow external apps to call this API) ──
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PUT, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, X-API-Key, Authorization');

// Handle preflight OPTIONS request (for browsers)
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

// ─── API Key Authentication ────────────────────────────────
$validApiKeys = [
    'FG-API-ADMIN-2026'   => ['role' => 'admin',    'name' => 'Admin App'],
    'FG-API-MOBILE-2026'  => ['role' => 'customer', 'name' => 'Mobile App'],
    'FG-API-PARTNER-2026' => ['role' => 'partner',  'name' => 'Partner System'],
];

$apiKey = $_SERVER['HTTP_X_API_KEY'] ?? $_GET['api_key'] ?? '';

if (empty($apiKey) || !isset($validApiKeys[$apiKey])) {
    http_response_code(401);
    echo json_encode([
        'success' => false,
        'error'   => 'Unauthorized. Provide a valid API key in the X-API-Key header.',
        'code'    => 401
    ]);
    exit;
}

$apiCaller = $validApiKeys[$apiKey];

// ─── Route the request ─────────────────────────────────────
$method   = $_SERVER['REQUEST_METHOD'];
$endpoint = $_GET['endpoint'] ?? '';
$db       = getDB();

// Helper: send JSON response
function respond($data, $code = 200) {
    http_response_code($code);
    echo json_encode($data, JSON_PRETTY_PRINT);
    exit;
}

// Helper: get request body as array
function getBody(): array {
    $raw = file_get_contents('php://input');
    return json_decode($raw, true) ?? [];
}

// ══════════════════════════════════════════════════════════
// ENDPOINTS
// ══════════════════════════════════════════════════════════

// ── GET /api.php?endpoint=status ─────────────────────────
// Check if API is online
if ($endpoint === 'status') {
    respond([
        'success'   => true,
        'system'    => 'FraudGuard API',
        'version'   => '1.0.0',
        'status'    => 'online',
        'timestamp' => date('Y-m-d H:i:s'),
        'caller'    => $apiCaller['name'],
    ]);
}

// ── POST /api.php?endpoint=login ─────────────────────────
// Login and get user info
if ($endpoint === 'login' && $method === 'POST') {
    $body     = getBody();
    $email    = filter_var($body['email'] ?? '', FILTER_SANITIZE_EMAIL);
    $password = $body['password'] ?? '';

    if (!$email || !$password) {
        respond(['success' => false, 'error' => 'Email and password required.'], 400);
    }

    $stmt = $db->prepare("SELECT * FROM users WHERE email = ? AND status = 'active'");
    $stmt->execute([$email]);
    $user = $stmt->fetch();

    if (!$user || !password_verify($password, $user['password_hash'])) {
        respond(['success' => false, 'error' => 'Invalid credentials or account inactive.'], 401);
    }

    // Generate a simple session token (in production use JWT)
    $token = base64_encode($user['user_id'] . ':' . hash('sha256', $user['email'] . date('Y-m-d')));

    $db->prepare("UPDATE users SET last_login = NOW() WHERE user_id = ?")->execute([$user['user_id']]);

    respond([
        'success'    => true,
        'token'      => $token,
        'user' => [
            'user_id'    => $user['user_id'],
            'full_name'  => $user['full_name'],
            'email'      => $user['email'],
            'phone'      => $user['phone'],
            'role'       => $user['role'],
            'account_no' => $user['account_no'],
            'balance'    => (float)$user['balance'],
            'status'     => $user['status'],
        ]
    ]);
}

// ── GET /api.php?endpoint=account&user_id=2 ───────────────
// Get account details for a user
if ($endpoint === 'account' && $method === 'GET') {
    $userId = (int)($_GET['user_id'] ?? 0);
    if (!$userId) respond(['success' => false, 'error' => 'user_id required.'], 400);

    $stmt = $db->prepare("SELECT user_id,full_name,email,phone,account_no,balance,status FROM users WHERE user_id = ?");
    $stmt->execute([$userId]);
    $user = $stmt->fetch();

    if (!$user) respond(['success' => false, 'error' => 'User not found.'], 404);

    respond(['success' => true, 'data' => $user]);
}

// ── GET /api.php?endpoint=balance&user_id=2 ───────────────
// Get account balance only
if ($endpoint === 'balance' && $method === 'GET') {
    $userId = (int)($_GET['user_id'] ?? 0);
    if (!$userId) respond(['success' => false, 'error' => 'user_id required.'], 400);

    $stmt = $db->prepare("SELECT balance, account_no FROM users WHERE user_id = ?");
    $stmt->execute([$userId]);
    $row = $stmt->fetch();

    if (!$row) respond(['success' => false, 'error' => 'User not found.'], 404);

    respond([
        'success'    => true,
        'account_no' => $row['account_no'],
        'balance'    => (float)$row['balance'],
        'currency'   => 'UGX',
        'timestamp'  => date('Y-m-d H:i:s'),
    ]);
}

// ── GET /api.php?endpoint=transactions&user_id=2 ──────────
// Get transaction history for a user
if ($endpoint === 'transactions' && $method === 'GET') {
    $userId = (int)($_GET['user_id'] ?? 0);
    $limit  = min((int)($_GET['limit'] ?? 20), 100);

    if (!$userId) respond(['success' => false, 'error' => 'user_id required.'], 400);

    $stmt = $db->prepare("
        SELECT t.txn_id, t.txn_reference, t.txn_type, t.amount, t.currency,
               t.channel, t.status, t.fraud_score, t.location, t.created_at,
               s.full_name as sender_name, s.account_no as sender_acc,
               r.full_name as receiver_name, r.account_no as receiver_acc
        FROM transactions t
        LEFT JOIN users s ON t.sender_id   = s.user_id
        LEFT JOIN users r ON t.receiver_id = r.user_id
        WHERE t.sender_id = ? OR t.receiver_id = ?
        ORDER BY t.created_at DESC
        LIMIT ?
    ");
    $stmt->execute([$userId, $userId, $limit]);
    $txns = $stmt->fetchAll();

    respond([
        'success' => true,
        'count'   => count($txns),
        'data'    => $txns
    ]);
}

// ── POST /api.php?endpoint=transfer ───────────────────────
// Submit a money transfer
// Body: { sender_id, receiver_account, amount, channel, location }
if ($endpoint === 'transfer' && $method === 'POST') {
    require_once 'php/fraud_engine.php';

    $body        = getBody();
    $senderId    = (int)($body['sender_id'] ?? 0);
    $receiverAcc = sanitize($body['receiver_account'] ?? '');
    $amount      = (float)($body['amount'] ?? 0);
    $channel     = sanitize($body['channel'] ?? 'mobile_money');
    $location    = sanitize($body['location'] ?? 'Unknown');
    $deviceId    = sanitize($body['device_id'] ?? 'API-DEVICE');
    $ip          = $_SERVER['REMOTE_ADDR'] ?? '0.0.0.0';

    if (!$senderId || !$receiverAcc || $amount <= 0) {
        respond(['success' => false, 'error' => 'sender_id, receiver_account, and amount are required.'], 400);
    }

    // Check sender balance
    $balStmt = $db->prepare("SELECT balance FROM users WHERE user_id = ? AND status = 'active'");
    $balStmt->execute([$senderId]);
    $sender = $balStmt->fetch();
    if (!$sender) respond(['success' => false, 'error' => 'Sender not found or account inactive.'], 404);
    if ((float)$sender['balance'] < $amount) respond(['success' => false, 'error' => 'Insufficient balance.'], 422);

    // Find receiver
    $recStmt = $db->prepare("SELECT user_id, full_name FROM users WHERE account_no = ? AND status = 'active'");
    $recStmt->execute([$receiverAcc]);
    $receiver = $recStmt->fetch();
    if (!$receiver) respond(['success' => false, 'error' => 'Receiver account not found.'], 404);

    // Run fraud detection
    $detector    = new FraudDetector();
    $fraudResult = $detector->evaluate([
        'sender_id'  => $senderId,
        'amount'     => $amount,
        'location'   => $location,
        'ip_address' => $ip,
        'device_id'  => $deviceId,
    ]);

    // Set status
    $txnStatus = 'completed';
    if ($fraudResult['action'] === 'block') $txnStatus = 'blocked';
    elseif ($fraudResult['action'] === 'flag') $txnStatus = 'flagged';

    $ref = generateRef('TXN');
    $db->prepare("
        INSERT INTO transactions
          (sender_id, receiver_id, txn_reference, txn_type, amount, channel, device_id, ip_address, location, status, fraud_score)
        VALUES (?,?,?,'transfer',?,?,?,?,?,?,?)
    ")->execute([$senderId, $receiver['user_id'], $ref, $amount, $channel, $deviceId, $ip, $location, $txnStatus, $fraudResult['score']]);

    $txnId = (int)$db->lastInsertId();

    // Save alerts
    if (!empty($fraudResult['flags'])) {
        $detector->saveAlerts($txnId, $senderId, $fraudResult);
    }

    // Debit/credit if completed
    if ($txnStatus === 'completed') {
        $db->prepare("UPDATE users SET balance = balance - ? WHERE user_id = ?")->execute([$amount, $senderId]);
        $db->prepare("UPDATE users SET balance = balance + ? WHERE user_id = ?")->execute([$amount, $receiver['user_id']]);
    }

    logAudit($senderId, "API Transfer $ref – $txnStatus", 'api');

    respond([
        'success'       => $txnStatus !== 'blocked',
        'reference'     => $ref,
        'status'        => $txnStatus,
        'fraud_score'   => $fraudResult['score'],
        'fraud_action'  => $fraudResult['action'],
        'flags'         => array_column($fraudResult['flags'], 'detail'),
        'amount'        => $amount,
        'currency'      => 'UGX',
        'receiver'      => $receiver['full_name'],
        'timestamp'     => date('Y-m-d H:i:s'),
    ], $txnStatus === 'blocked' ? 422 : 200);
}

// ── POST /api.php?endpoint=deposit ────────────────────────
// Submit a deposit request
// Body: { user_id, amount, payment_method, payment_ref, notes }
if ($endpoint === 'deposit' && $method === 'POST') {
    $body   = getBody();
    $userId = (int)($body['user_id'] ?? 0);
    $amount = (float)($body['amount'] ?? 0);
    $method_pay = sanitize($body['payment_method'] ?? '');
    $payRef = sanitize($body['payment_ref'] ?? '');
    $notes  = sanitize($body['notes'] ?? '');

    if (!$userId || $amount < 1000 || !$method_pay) {
        respond(['success' => false, 'error' => 'user_id, amount (min 1000), and payment_method are required.'], 400);
    }

    $depRef = generateRef('DEP');
    $db->prepare("
        INSERT INTO deposit_requests (user_id, deposit_reference, amount, payment_method, payment_ref, notes)
        VALUES (?,?,?,?,?,?)
    ")->execute([$userId, $depRef, $amount, $method_pay, $payRef, $notes]);

    respond([
        'success'   => true,
        'reference' => $depRef,
        'message'   => 'Deposit request submitted. Pending admin approval.',
        'amount'    => $amount,
        'currency'  => 'UGX',
        'method'    => $method_pay,
    ], 201);
}

// ── POST /api.php?endpoint=report_fraud ───────────────────
// Report a fraud case
// Body: { user_id, txn_reference, fraud_type, amount_claimed, description }
if ($endpoint === 'report_fraud' && $method === 'POST') {
    $body        = getBody();
    $userId      = (int)($body['user_id'] ?? 0);
    $txnRef      = sanitize($body['txn_reference'] ?? '');
    $fraudType   = sanitize($body['fraud_type'] ?? '');
    $amountClaim = (float)($body['amount_claimed'] ?? 0);
    $desc        = sanitize($body['description'] ?? '');

    if (!$userId || !$txnRef || !$fraudType || !$desc || $amountClaim <= 0) {
        respond(['success' => false, 'error' => 'All fields required: user_id, txn_reference, fraud_type, amount_claimed, description.'], 400);
    }

    // Verify transaction
    $txnStmt = $db->prepare("SELECT txn_id FROM transactions WHERE txn_reference = ? AND sender_id = ?");
    $txnStmt->execute([$txnRef, $userId]);
    $txn = $txnStmt->fetch();
    if (!$txn) respond(['success' => false, 'error' => 'Transaction not found or not linked to this user.'], 404);

    $caseRef  = generateRef('CASE');
    $priority = $amountClaim >= 5000000 ? 'high' : ($amountClaim >= 1000000 ? 'medium' : 'low');

    $db->prepare("
        INSERT INTO refund_cases (txn_id, complainant_id, case_reference, fraud_type, description, amount_claimed, priority)
        VALUES (?,?,?,?,?,?,?)
    ")->execute([$txn['txn_id'], $userId, $caseRef, $fraudType, $desc, $amountClaim, $priority]);

    respond([
        'success'         => true,
        'case_reference'  => $caseRef,
        'priority'        => $priority,
        'message'         => 'Fraud case submitted successfully. An officer will review it shortly.',
        'amount_claimed'  => $amountClaim,
        'currency'        => 'UGX',
    ], 201);
}

// ── GET /api.php?endpoint=notifications&user_id=2 ─────────
// Get notifications for a user
if ($endpoint === 'notifications' && $method === 'GET') {
    $userId = (int)($_GET['user_id'] ?? 0);
    if (!$userId) respond(['success' => false, 'error' => 'user_id required.'], 400);

    $stmt = $db->prepare("
        SELECT * FROM notifications WHERE user_id = ?
        ORDER BY created_at DESC LIMIT 30
    ");
    $stmt->execute([$userId]);
    $notifs = $stmt->fetchAll();

    // Mark as read
    $db->prepare("UPDATE notifications SET is_read = 1 WHERE user_id = ?")->execute([$userId]);

    respond([
        'success' => true,
        'count'   => count($notifs),
        'data'    => $notifs
    ]);
}

// ── GET /api.php?endpoint=fraud_score&txn_id=5 ────────────
// Get fraud score and details for a specific transaction
if ($endpoint === 'fraud_score' && $method === 'GET') {
    $txnId = (int)($_GET['txn_id'] ?? 0);
    if (!$txnId) respond(['success' => false, 'error' => 'txn_id required.'], 400);

    $stmt = $db->prepare("
        SELECT t.txn_reference, t.amount, t.fraud_score, t.status, t.location, t.created_at,
               GROUP_CONCAT(fa.alert_type SEPARATOR ', ') as alert_types,
               GROUP_CONCAT(fa.description SEPARATOR ' | ') as alert_details,
               MAX(fa.severity) as max_severity
        FROM transactions t
        LEFT JOIN fraud_alerts fa ON t.txn_id = fa.txn_id
        WHERE t.txn_id = ?
        GROUP BY t.txn_id
    ");
    $stmt->execute([$txnId]);
    $row = $stmt->fetch();

    if (!$row) respond(['success' => false, 'error' => 'Transaction not found.'], 404);

    respond([
        'success'       => true,
        'txn_reference' => $row['txn_reference'],
        'amount'        => (float)$row['amount'],
        'fraud_score'   => (float)$row['fraud_score'],
        'risk_level'    => (float)$row['fraud_score'] >= 80 ? 'critical' : ((float)$row['fraud_score'] >= 60 ? 'high' : ((float)$row['fraud_score'] >= 35 ? 'medium' : 'low')),
        'status'        => $row['status'],
        'location'      => $row['location'],
        'alert_types'   => $row['alert_types'],
        'alert_details' => $row['alert_details'],
        'severity'      => $row['max_severity'],
        'timestamp'     => $row['created_at'],
    ]);
}

// ── GET /api.php?endpoint=stats ───────────────────────────
// Get system-wide statistics (admin only)
if ($endpoint === 'stats' && $method === 'GET') {
    if ($apiCaller['role'] !== 'admin') {
        respond(['success' => false, 'error' => 'Admin API key required for stats.'], 403);
    }

    respond([
        'success' => true,
        'data' => [
            'total_transactions' => (int)$db->query("SELECT COUNT(*) FROM transactions")->fetchColumn(),
            'total_users'        => (int)$db->query("SELECT COUNT(*) FROM users WHERE role='customer'")->fetchColumn(),
            'flagged_today'      => (int)$db->query("SELECT COUNT(*) FROM transactions WHERE status IN ('flagged','blocked') AND DATE(created_at)=CURDATE()")->fetchColumn(),
            'open_cases'         => (int)$db->query("SELECT COUNT(*) FROM refund_cases WHERE status IN ('submitted','under_review')")->fetchColumn(),
            'unresolved_alerts'  => (int)$db->query("SELECT COUNT(*) FROM fraud_alerts WHERE is_resolved=0")->fetchColumn(),
            'total_blocked'      => (int)$db->query("SELECT COUNT(*) FROM transactions WHERE status='blocked'")->fetchColumn(),
            'timestamp'          => date('Y-m-d H:i:s'),
        ]
    ]);
}

// ── 404 for unknown endpoints ──────────────────────────────
respond([
    'success'   => false,
    'error'     => "Unknown endpoint: '$endpoint'",
    'available' => [
        'GET  ?endpoint=status',
        'POST ?endpoint=login',
        'GET  ?endpoint=account&user_id={id}',
        'GET  ?endpoint=balance&user_id={id}',
        'GET  ?endpoint=transactions&user_id={id}',
        'POST ?endpoint=transfer',
        'POST ?endpoint=deposit',
        'POST ?endpoint=report_fraud',
        'GET  ?endpoint=notifications&user_id={id}',
        'GET  ?endpoint=fraud_score&txn_id={id}',
        'GET  ?endpoint=stats  [admin key only]',
    ]
], 404);
