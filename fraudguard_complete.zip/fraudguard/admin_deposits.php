<?php
// ============================================================
//  FraudGuard – Admin Deposit Management Page
// ============================================================
require_once 'php/config.php';
startSession(); requireLogin();
if (!isAdmin()) { header('Location: dashboard.php'); exit; }
$user = currentUser();
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Deposit Requests – FraudGuard Admin</title>
<link href="https://fonts.googleapis.com/css2?family=Space+Grotesk:wght@300;400;500;600;700&family=Syne:wght@700;800&display=swap" rel="stylesheet">
<link rel="stylesheet" href="css/style.css">
</head>
<body>
<div class="app-layout">

  <!-- SIDEBAR -->
  <aside class="sidebar">
    <div class="sidebar-brand">
      <div class="icon">🛡️</div>
      <div class="name">Fraud<span>Guard</span></div>
    </div>
    <div class="sidebar-user">
      <div class="avatar" style="background:linear-gradient(135deg,#ff6b35,#ff4444)">
        <?= strtoupper(substr($user['full_name'],0,1)) ?>
      </div>
      <div class="uname"><?= htmlspecialchars($user['full_name']) ?></div>
      <div class="urole" style="color:var(--danger)"><?= ucfirst(str_replace('_',' ',$user['role'])) ?></div>
    </div>
    <nav class="sidebar-nav">
      <div class="nav-section-title">Overview</div>
      <a href="admin_dashboard.php" class="nav-link"><span class="icon">📊</span> Dashboard</a>
      <a href="transactions.php"    class="nav-link"><span class="icon">💳</span> Transactions</a>
      <a href="admin_alerts.php"    class="nav-link"><span class="icon">⚠️</span> Fraud Alerts</a>
      <div class="nav-section-title">Management</div>
      <a href="admin_cases.php"    class="nav-link"><span class="icon">📁</span> Refund Cases</a>
      <a href="admin_deposits.php" class="nav-link active"><span class="icon">💰</span> Deposit Requests</a>
      <a href="admin_users.php"    class="nav-link"><span class="icon">👥</span> Users</a>
      <div class="nav-section-title">Account</div>
      <a href="notifications.php"  class="nav-link"><span class="icon">🔔</span> Notifications</a>
    </nav>
    <div class="sidebar-footer">
      <a href="php/auth.php?action=logout" class="nav-link"><span class="icon">🚪</span> Logout</a>
    </div>
  </aside>

  <!-- MAIN CONTENT -->
  <div class="main-content">
    <div class="topbar">
      <div class="topbar-title">💰 Deposit Requests</div>
      <div class="topbar-actions">
        <select class="form-select" id="filter-status" style="width:160px" onchange="loadDeposits()">
          <option value="">All Statuses</option>
          <option value="pending">Pending</option>
          <option value="approved">Approved</option>
          <option value="rejected">Rejected</option>
        </select>
        <button class="btn btn-secondary btn-sm" onclick="loadDeposits()">🔄 Refresh</button>
      </div>
    </div>

    <div class="page-content">
      <div id="toast-container"></div>

      <!-- Summary Stats -->
      <div class="stats-grid" style="margin-bottom:24px">
        <div class="stat-card blue">
          <div class="stat-icon">📥</div>
          <div class="stat-value" id="st-total">—</div>
          <div class="stat-label">Total Requests</div>
        </div>
        <div class="stat-card orange">
          <div class="stat-icon">⏳</div>
          <div class="stat-value" id="st-pending">—</div>
          <div class="stat-label">Pending Approval</div>
        </div>
        <div class="stat-card green">
          <div class="stat-icon">✅</div>
          <div class="stat-value" id="st-approved">—</div>
          <div class="stat-label">Approved Today</div>
        </div>
        <div class="stat-card red">
          <div class="stat-icon">💵</div>
          <div class="stat-value" id="st-amount">—</div>
          <div class="stat-label">Total Approved (UGX)</div>
        </div>
      </div>

      <!-- Deposits Table -->
      <div class="data-card">
        <div class="data-card-header">
          <div class="data-card-title">📋 All Deposit Requests</div>
          <span id="dep-count" style="font-size:13px;color:var(--muted)"></span>
        </div>
        <div style="overflow-x:auto">
          <table class="data-table">
            <thead>
              <tr>
                <th>Reference</th>
                <th>Customer</th>
                <th>Amount Requested</th>
                <th>Payment Method</th>
                <th>Payment Ref</th>
                <th>Notes</th>
                <th>Status</th>
                <th>Submitted</th>
                <th>Action</th>
              </tr>
            </thead>
            <tbody id="deposits-body">
              <tr>
                <td colspan="9" style="text-align:center;color:var(--muted);padding:40px">
                  Loading...
                </td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  </div>
</div>

<!-- APPROVE/REJECT MODAL -->
<div class="modal-overlay" id="depositModal">
  <div class="modal" style="max-width:500px">
    <div style="display:flex;justify-content:space-between;align-items:start;margin-bottom:20px">
      <div>
        <div class="modal-title" id="modal-dep-ref">Process Deposit</div>
        <div class="modal-sub" id="modal-dep-info"></div>
      </div>
      <button onclick="closeModal('depositModal')"
        style="background:none;border:none;color:var(--muted);font-size:24px;cursor:pointer;line-height:1">×</button>
    </div>

    <!-- Customer info panel -->
    <div style="background:var(--surface2);border-radius:12px;padding:16px;margin-bottom:20px;font-size:14px">
      <div style="display:grid;grid-template-columns:1fr 1fr;gap:10px">
        <div><span style="color:var(--muted)">Customer:</span><br><strong id="md-name"></strong></div>
        <div><span style="color:var(--muted)">Phone:</span><br><span id="md-phone"></span></div>
        <div><span style="color:var(--muted)">Account No:</span><br>
          <span id="md-acc" style="font-family:monospace;color:var(--accent)"></span></div>
        <div><span style="color:var(--muted)">Amount Requested:</span><br>
          <strong id="md-amount" style="color:var(--warning)"></strong></div>
        <div><span style="color:var(--muted)">Payment Method:</span><br><span id="md-method"></span></div>
        <div><span style="color:var(--muted)">Payment Reference:</span><br>
          <span id="md-payref" style="font-family:monospace;font-size:12px"></span></div>
      </div>
      <div style="margin-top:10px" id="md-notes-wrap">
        <span style="color:var(--muted)">Customer Notes:</span><br>
        <span id="md-notes" style="font-size:13px"></span>
      </div>
    </div>

    <div id="modal-alert"></div>

    <div class="form-group">
      <label class="form-label">Amount to Credit (UGX)</label>
      <input type="number" class="form-input" id="approve-amount"
        placeholder="Enter amount to credit to user account">
      <div style="font-size:12px;color:var(--muted);margin-top:6px">
        You can adjust this if the actual payment received differs from the request.
      </div>
    </div>

    <div class="form-group">
      <label class="form-label">Admin Notes (sent to customer)</label>
      <textarea class="form-textarea" id="approve-notes"
        placeholder="e.g. Payment confirmed via MTN. Credited to account."
        style="min-height:80px"></textarea>
    </div>

    <input type="hidden" id="modal-dep-id">

    <div style="display:flex;gap:12px;margin-top:8px">
      <button class="btn btn-secondary" onclick="closeModal('depositModal')" style="flex:1">
        Cancel
      </button>
      <button class="btn btn-danger" onclick="processDeposit('reject')" style="flex:1">
        ❌ Reject
      </button>
      <button class="btn btn-primary" onclick="processDeposit('approve')" style="flex:2">
        ✅ Approve & Credit
      </button>
    </div>
  </div>
</div>

<script>
let allDeposits = [];

// ── Helpers ──────────────────────────────────────────────
function fmtUGX(n) {
  return 'UGX ' + Number(n).toLocaleString();
}
function fmtDate(s) {
  return new Date(s).toLocaleString('en-UG', {
    day:'2-digit', month:'short', year:'numeric',
    hour:'2-digit', minute:'2-digit'
  });
}
function openModal(id)  { document.getElementById(id).classList.add('open'); }
function closeModal(id) { document.getElementById(id).classList.remove('open'); }

function toast(msg, type = 'success') {
  const t = document.createElement('div');
  t.className = `toast toast-${type}`;
  t.textContent = msg;
  document.getElementById('toast-container').appendChild(t);
  setTimeout(() => t.remove(), 4000);
}

// ── Load all deposits ─────────────────────────────────────
async function loadDeposits() {
  const res  = await fetch('php/deposit.php?action=admin_get_deposits');
  const json = await res.json();
  if (!json.success) return;

  allDeposits = json.data;

  // Filter
  const filter = document.getElementById('filter-status').value;
  const deps   = filter ? allDeposits.filter(d => d.status === filter) : allDeposits;

  // Stats
  const pending  = allDeposits.filter(d => d.status === 'pending').length;
  const approved = allDeposits.filter(d => d.status === 'approved').length;
  const totalAmt = allDeposits
    .filter(d => d.status === 'approved')
    .reduce((s, d) => s + parseFloat(d.amount_approved || 0), 0);

  document.getElementById('st-total').textContent   = allDeposits.length;
  document.getElementById('st-pending').textContent = pending;
  document.getElementById('st-approved').textContent= approved;
  document.getElementById('st-amount').textContent  = fmtUGX(totalAmt);
  document.getElementById('dep-count').textContent  = deps.length + ' request(s)';

  const tbody = document.getElementById('deposits-body');

  if (!deps.length) {
    tbody.innerHTML = `
      <tr>
        <td colspan="9" style="text-align:center;padding:50px">
          <div class="empty-state">
            <div class="icon">💰</div>
            <p>No deposit requests found.</p>
          </div>
        </td>
      </tr>`;
    return;
  }

  tbody.innerHTML = deps.map(d => `
    <tr>
      <td>
        <span style="font-family:monospace;color:var(--accent);font-size:12px">
          ${d.deposit_reference}
        </span>
      </td>
      <td>
        <strong>${d.full_name}</strong><br>
        <span style="font-size:12px;color:var(--muted)">${d.phone}</span>
      </td>
      <td style="font-weight:700;color:var(--warning)">${fmtUGX(d.amount)}</td>
      <td style="font-size:13px">
        ${d.payment_method === 'MTN Mobile Money'  ? '📱 ' : ''}
        ${d.payment_method === 'Airtel Money'       ? '📱 ' : ''}
        ${d.payment_method === 'Bank Transfer'      ? '🏦 ' : ''}
        ${d.payment_method === 'Cash Deposit'       ? '🏪 ' : ''}
        ${d.payment_method}
      </td>
      <td style="font-family:monospace;font-size:12px;color:var(--muted)">
        ${d.payment_ref || '—'}
      </td>
      <td style="font-size:12px;color:var(--muted);max-width:150px">
        ${d.notes || '—'}
      </td>
      <td>
        <span class="badge badge-${
          d.status === 'approved' ? 'completed' :
          d.status === 'rejected' ? 'blocked' : 'pending'
        }">
          ${d.status === 'approved' ? '✅ Approved' :
            d.status === 'rejected' ? '❌ Rejected' : '⏳ Pending'}
        </span>
        ${d.status === 'approved'
          ? `<br><span style="font-size:11px;color:var(--success)">${fmtUGX(d.amount_approved)} credited</span>`
          : ''}
      </td>
      <td style="color:var(--muted);font-size:12px">${fmtDate(d.created_at)}</td>
      <td>
        ${d.status === 'pending'
          ? `<button class="btn btn-secondary btn-sm" onclick="openDeposit(${d.deposit_id})">
               Review →
             </button>`
          : `<span style="font-size:12px;color:var(--muted)">
               ${d.admin_notes ? d.admin_notes.substring(0,30) + '...' : 'Processed'}
             </span>`
        }
      </td>
    </tr>
  `).join('');
}

// ── Open deposit review modal ────────────────────────────
function openDeposit(id) {
  const d = allDeposits.find(x => x.deposit_id == id);
  if (!d) return;

  document.getElementById('modal-dep-id').value      = d.deposit_id;
  document.getElementById('modal-dep-ref').textContent = '💰 ' + d.deposit_reference;
  document.getElementById('modal-dep-info').textContent =
    d.payment_method + ' — ' + fmtUGX(d.amount);

  document.getElementById('md-name').textContent   = d.full_name;
  document.getElementById('md-phone').textContent  = d.phone;
  document.getElementById('md-acc').textContent    = d.account_no || '—';
  document.getElementById('md-amount').textContent = fmtUGX(d.amount);
  document.getElementById('md-method').textContent = d.payment_method;
  document.getElementById('md-payref').textContent = d.payment_ref || 'Not provided';
  document.getElementById('md-notes').textContent  = d.notes || 'None';

  // Pre-fill amount
  document.getElementById('approve-amount').value = d.amount;
  document.getElementById('approve-notes').value  = '';
  document.getElementById('modal-alert').innerHTML = '';

  openModal('depositModal');
}

// ── Approve or Reject ────────────────────────────────────
async function processDeposit(action) {
  const depId  = document.getElementById('modal-dep-id').value;
  const amount = document.getElementById('approve-amount').value;
  const notes  = document.getElementById('approve-notes').value;
  const alertEl= document.getElementById('modal-alert');

  if (action === 'approve' && (!amount || parseFloat(amount) <= 0)) {
    alertEl.innerHTML =
      '<div class="alert alert-error">⚠️ Please enter a valid amount to credit.</div>';
    return;
  }

  if (action === 'reject' && !notes.trim()) {
    alertEl.innerHTML =
      '<div class="alert alert-error">⚠️ Please enter a reason for rejection.</div>';
    return;
  }

  const body = new FormData();
  body.append('action',          action === 'approve' ? 'approve_deposit' : 'reject_deposit');
  body.append('deposit_id',      depId);
  body.append('amount_approved', amount);
  body.append('admin_notes',     notes);

  const res  = await fetch('php/deposit.php', { method: 'POST', body });
  const json = await res.json();

  if (json.success) {
    alertEl.innerHTML =
      `<div class="alert alert-success">✅ ${json.message}</div>`;
    setTimeout(() => {
      closeModal('depositModal');
      loadDeposits();
    }, 1800);
  } else {
    alertEl.innerHTML =
      `<div class="alert alert-error">⚠️ ${json.message}</div>`;
  }
}

// ── Initial load ─────────────────────────────────────────
loadDeposits();

// Auto-refresh every 30 seconds for new requests
setInterval(loadDeposits, 30000);
</script>
</body>
</html>
