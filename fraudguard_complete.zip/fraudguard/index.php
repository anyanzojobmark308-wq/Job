<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>FraudGuard – Secure Financial Protection</title>
<link href="https://fonts.googleapis.com/css2?family=Space+Grotesk:wght@300;400;500;600;700&family=Syne:wght@700;800&display=swap" rel="stylesheet">
<link rel="stylesheet" href="css/style.css">
<style>
:root {
  --bg: #0a0e1a;
  --surface: #111827;
  --surface2: #1a2332;
  --border: #1f2d42;
  --accent: #00d4ff;
  --accent2: #ff6b35;
  --danger: #ff4444;
  --success: #00e676;
  --warning: #ffb300;
  --text: #e8eaf0;
  --muted: #6b7fa3;
  --white: #ffffff;
  --grad: linear-gradient(135deg, #00d4ff 0%, #0066ff 100%);
}
* { margin:0; padding:0; box-sizing:border-box; }
body {
  font-family: 'Space Grotesk', sans-serif;
  background: var(--bg);
  color: var(--text);
  min-height: 100vh;
  display: flex;
  overflow: hidden;
}

/* ── Left Panel ── */
.auth-left {
  flex: 1;
  background: linear-gradient(145deg, #0d1b2e 0%, #0a0e1a 60%, #0d1424 100%);
  display: flex;
  flex-direction: column;
  justify-content: center;
  padding: 60px;
  position: relative;
  overflow: hidden;
}
.auth-left::before {
  content: '';
  position: absolute;
  width: 500px; height: 500px;
  background: radial-gradient(circle, rgba(0,212,255,0.08) 0%, transparent 70%);
  top: -100px; left: -100px;
  animation: pulse 6s ease-in-out infinite;
}
.auth-left::after {
  content: '';
  position: absolute;
  width: 300px; height: 300px;
  background: radial-gradient(circle, rgba(255,107,53,0.06) 0%, transparent 70%);
  bottom: 50px; right: -50px;
  animation: pulse 8s ease-in-out infinite reverse;
}
@keyframes pulse { 0%,100%{transform:scale(1);opacity:0.8} 50%{transform:scale(1.2);opacity:1} }

.brand {
  display: flex; align-items: center; gap: 14px; margin-bottom: 60px; position: relative; z-index: 1;
}
.brand-icon {
  width: 48px; height: 48px;
  background: var(--grad);
  border-radius: 12px;
  display: flex; align-items: center; justify-content: center;
  font-size: 22px;
}
.brand-name { font-family: 'Syne', sans-serif; font-size: 26px; font-weight: 800; color: var(--white); }
.brand-name span { color: var(--accent); }

.hero-title {
  font-family: 'Syne', sans-serif;
  font-size: 46px; font-weight: 800;
  line-height: 1.1;
  margin-bottom: 24px;
  position: relative; z-index: 1;
}
.hero-title span { color: var(--accent); }
.hero-sub { font-size: 17px; color: var(--muted); line-height: 1.7; max-width: 420px; margin-bottom: 50px; position: relative; z-index: 1; }

.stats-row { display: flex; gap: 28px; position: relative; z-index: 1; }
.stat-card {
  background: rgba(255,255,255,0.03);
  border: 1px solid var(--border);
  border-radius: 14px;
  padding: 20px 24px;
  flex: 1;
}
.stat-val { font-size: 28px; font-weight: 700; color: var(--white); }
.stat-val.green { color: var(--success); }
.stat-val.orange { color: var(--accent2); }
.stat-lbl { font-size: 12px; color: var(--muted); margin-top: 4px; text-transform: uppercase; letter-spacing: 0.5px; }

/* ── Right Panel ── */
.auth-right {
  width: 480px;
  background: var(--surface);
  display: flex;
  align-items: center;
  justify-content: center;
  padding: 40px;
  border-left: 1px solid var(--border);
}
.auth-box { width: 100%; max-width: 380px; }

.tab-row { display: flex; background: var(--surface2); border-radius: 10px; padding: 4px; margin-bottom: 32px; }
.tab-btn {
  flex: 1; padding: 10px; border: none; background: transparent;
  color: var(--muted); font-family: 'Space Grotesk', sans-serif;
  font-size: 14px; font-weight: 500; border-radius: 8px; cursor: pointer; transition: all .2s;
}
.tab-btn.active { background: var(--accent); color: #000; font-weight: 600; }

.auth-title { font-size: 24px; font-weight: 700; margin-bottom: 8px; }
.auth-sub { font-size: 14px; color: var(--muted); margin-bottom: 28px; }

.form-group { margin-bottom: 18px; }
.form-label { display: block; font-size: 13px; font-weight: 500; color: var(--muted); margin-bottom: 8px; text-transform: uppercase; letter-spacing: 0.5px; }
.form-input {
  width: 100%; padding: 13px 16px;
  background: var(--surface2);
  border: 1px solid var(--border);
  border-radius: 10px;
  color: var(--text);
  font-family: 'Space Grotesk', sans-serif;
  font-size: 15px;
  transition: border-color .2s;
}
.form-input:focus { outline: none; border-color: var(--accent); }

.btn-primary {
  width: 100%; padding: 14px;
  background: var(--grad);
  border: none; border-radius: 10px;
  color: #000; font-family: 'Space Grotesk', sans-serif;
  font-size: 15px; font-weight: 700; cursor: pointer;
  transition: opacity .2s, transform .1s;
  margin-top: 8px;
}
.btn-primary:hover { opacity: 0.9; }
.btn-primary:active { transform: scale(0.99); }

.alert-msg {
  padding: 12px 16px; border-radius: 8px;
  font-size: 14px; margin-bottom: 16px;
}
.alert-error   { background: rgba(255,68,68,0.12); border: 1px solid rgba(255,68,68,0.3); color: #ff8a80; }
.alert-success { background: rgba(0,230,118,0.12); border: 1px solid rgba(0,230,118,0.3); color: #69f0ae; }

.form-panel { display: none; }
.form-panel.active { display: block; }

/* Shield animation */
.shield-anim {
  position: absolute; right: 60px; bottom: 60px; z-index: 0;
  font-size: 180px; opacity: 0.04;
  animation: spin-slow 20s linear infinite;
}
@keyframes spin-slow { from{transform:rotate(0deg)} to{transform:rotate(360deg)} }

@media(max-width:900px){
  .auth-left { display: none; }
  .auth-right { width: 100%; }
}
</style>
</head>
<body>

<!-- Left Panel -->
<div class="auth-left">
  <div class="brand">
    <div class="brand-icon">🛡️</div>
    <div class="brand-name">Fraud<span>Guard</span></div>
  </div>
  <h1 class="hero-title">Protecting Uganda's<br><span>Digital Finance</span></h1>
  <p class="hero-sub">Real-time fraud detection, intelligent prevention, and seamless refund support — all in one integrated platform.</p>
  <div class="stats-row">
    <div class="stat-card">
      <div class="stat-val green">99.2%</div>
      <div class="stat-lbl">Detection Rate</div>
    </div>
    <div class="stat-card">
      <div class="stat-val">&lt;2s</div>
      <div class="stat-lbl">Response Time</div>
    </div>
    <div class="stat-card">
      <div class="stat-val orange">24/7</div>
      <div class="stat-lbl">Monitoring</div>
    </div>
  </div>
  <div class="shield-anim">🛡️</div>
</div>

<!-- Right Panel -->
<div class="auth-right">
  <div class="auth-box">

    <!-- PHP Alerts -->
    <?php if (isset($_SESSION['error'])): ?>
      <div class="alert-msg alert-error"><?= htmlspecialchars($_SESSION['error']) ?></div>
      <?php unset($_SESSION['error']); ?>
    <?php endif; ?>
    <?php if (isset($_SESSION['success'])): ?>
      <div class="alert-msg alert-success"><?= htmlspecialchars($_SESSION['success']) ?></div>
      <?php unset($_SESSION['success']); ?>
    <?php endif; ?>

    <!-- Tabs -->
    <div class="tab-row">
      <button class="tab-btn active" onclick="switchTab('login')">Sign In</button>
      <button class="tab-btn" onclick="switchTab('register')">Register</button>
    </div>

    <!-- LOGIN -->
    <div id="panel-login" class="form-panel active">
      <div class="auth-title">Welcome back</div>
      <div class="auth-sub">Sign in to your FraudGuard account</div>
      <form action="php/auth.php" method="POST">
        <input type="hidden" name="action" value="login">
        <div class="form-group">
          <label class="form-label">Email Address</label>
          <input type="email" name="email" class="form-input" placeholder="you@example.com" required>
        </div>
        <div class="form-group">
          <label class="form-label">Password</label>
          <input type="password" name="password" class="form-input" placeholder="••••••••" required>
        </div>
        <button type="submit" class="btn-primary">Sign In →</button>
      </form>
      <p style="font-size:13px;color:var(--muted);margin-top:20px;text-align:center">
        Demo Admin: <strong style="color:var(--accent)">admin@fraudguard.ug</strong> / password123
      </p>
    </div>

    <!-- REGISTER -->
    <div id="panel-register" class="form-panel">
      <div class="auth-title">Create Account</div>
      <div class="auth-sub">Join FraudGuard for secure transactions</div>
      <form action="php/auth.php" method="POST">
        <input type="hidden" name="action" value="register">
        <div class="form-group">
          <label class="form-label">Full Name</label>
          <input type="text" name="full_name" class="form-input" placeholder="John Doe" required>
        </div>
        <div class="form-group">
          <label class="form-label">Email Address</label>
          <input type="email" name="email" class="form-input" placeholder="you@example.com" required>
        </div>
        <div class="form-group">
          <label class="form-label">Phone Number</label>
          <input type="tel" name="phone" class="form-input" placeholder="0701234567" required>
        </div>
        <div class="form-group">
          <label class="form-label">Password</label>
          <input type="password" name="password" class="form-input" placeholder="Min. 6 characters" required minlength="6">
        </div>
        <button type="submit" class="btn-primary">Create Account →</button>
      </form>
    </div>

  </div>
</div>

<script>
function switchTab(tab) {
  document.querySelectorAll('.tab-btn').forEach((b,i) => b.classList.toggle('active', (i===0&&tab==='login')||(i===1&&tab==='register')));
  document.querySelectorAll('.form-panel').forEach(p => p.classList.remove('active'));
  document.getElementById('panel-' + tab).classList.add('active');
}
<?php if(isset($_GET['page']) && $_GET['page']==='register'): ?>
switchTab('register');
<?php endif; ?>
</script>
</body>
</html>
