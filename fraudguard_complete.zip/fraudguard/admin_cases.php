<?php
// ============================================================
//  FraudGuard – Admin Refund Cases Management
// ============================================================
require_once 'php/config.php';
startSession(); requireLogin();
if (!isAdmin()) { header('Location: dashboard.php'); exit; }
$user = currentUser();
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Refund Cases – FraudGuard Admin</title>
<link href="https://fonts.googleapis.com/css2?family=Space+Grotesk:wght@300;400;500;600;700&family=Syne:wght@700;800&display=swap" rel="stylesheet">
<link rel="stylesheet" href="css/style.css">
</head>
<body>
<div class="app-layout">
  <aside class="sidebar">
    <div class="sidebar-brand"><div class="icon">🛡️</div><div class="name">Fraud<span>Guard</span></div></div>
    <div class="sidebar-user">
      <div class="avatar" style="background:linear-gradient(135deg,#ff6b35,#ff4444)"><?= strtoupper(substr($user['full_name'],0,1)) ?></div>
      <div class="uname"><?= htmlspecialchars($user['full_name']) ?></div>
      <div class="urole" style="color:var(--danger)"><?= ucfirst(str_replace('_',' ',$user['role'])) ?></div>
    </div>
    <nav class="sidebar-nav">
      <div class="nav-section-title">Overview</div>
      <a href="admin_dashboard.php" class="nav-link"><span class="icon">📊</span> Dashboard</a>
      <a href="admin_transactions.php" class="nav-link"><span class="icon">💳</span> All Transactions</a>
      <a href="admin_alerts.php" class="nav-link"><span class="icon">⚠️</span> Fraud Alerts</a>
      <div class="nav-section-title">Case Management</div>
      <a href="admin_cases.php" class="nav-link active"><span class="icon">📁</span> Refund Cases</a>
      <div class="nav-section-title">Administration</div>
      <a href="admin_users.php" class="nav-link"><span class="icon">👥</span> Users</a>
    </nav>
    <div class="sidebar-footer"><a href="php/auth.php?action=logout" class="nav-link"><span class="icon">🚪</span> Logout</a></div>
  </aside>

  <div class="main-content">
    <div class="topbar">
      <div class="topbar-title">Refund Cases Management</div>
      <div class="topbar-actions">
        <select class="form-select" id="filter-status" style="width:160px" onchange="loadCases()">
          <option value="">All Statuses</option>
          <option value="submitted">Submitted</option>
          <option value="under_review">Under Review</option>
          <option value="approved">Approved</option>
          <option value="rejected">Rejected</option>
          <option value="refunded">Refunded</option>
        </select>
      </div>
    </div>

    <div class="page-content">
      <div id="toast-container"></div>
      <div class="data-card">
        <div class="data-card-header">
          <div class="data-card-title">📁 All Refund Cases</div>
          <span style="font-size:13px; color:var(--muted)" id="case-count"></span>
        </div>
        <div style="overflow-x:auto">
          <table class="data-table">
            <thead><tr>
              <th>Case Ref</th><th>Complainant</th><th>Transaction</th>
              <th>Fraud Type</th><th>Claimed</th><th>Priority</th>
              <th>Status</th><th>Submitted</th><th>Actions</th>
            </tr></thead>
            <tbody id="cases-body">
              <tr><td colspan="9" style="text-align:center;color:var(--muted);padding:30px">Loading...</td></tr>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  </div>
</div>

<!-- CASE DETAIL MODAL -->
<div class="modal-overlay" id="caseModal">
  <div class="modal" style="max-width:600px">
    <div style="display:flex;justify-content:space-between;align-items:start;margin-bottom:20px">
      <div>
        <div class="modal-title" id="modal-case-ref">Case Details</div>
        <div class="modal-sub" id="modal-case-sub"></div>
      </div>
      <button onclick="closeModal('caseModal')" style="background:none;border:none;color:var(--muted);font-size:22px;cursor:pointer">×</button>
    </div>

    <div style="background:var(--surface2); border-radius:12px; padding:18px; margin-bottom:20px; font-size:14px">
      <div class="grid-2" style="gap:12px; margin-bottom:12px">
        <div><span style="color:var(--muted)">Complainant:</span> <strong id="md-name"></strong></div>
        <div><span style="color:var(--muted)">Phone:</span> <span id="md-phone"></span></div>
        <div><span style="color:var(--muted)">Email:</span> <span id="md-email" style="color:var(--accent)"></span></div>
        <div><span style="color:var(--muted)">Claimed Amount:</span> <strong id="md-amount" style="color:var(--warning)"></strong></div>
      </div>
      <div><span style="color:var(--muted)">Description:</span><br><div id="md-desc" style="margin-top:6px; line-height:1.6"></div></div>
    </div>

    <div id="update-alert"></div>

    <div class="form-group">
      <label class="form-label">Update Status</label>
      <select class="form-select" id="update-status">
        <option value="under_review">Under Review</option>
        <option value="approved">Approved</option>
        <option value="rejected">Rejected</option>
        <option value="refunded">Refunded</option>
      </select>
    </div>
    <div class="form-group">
      <label class="form-label">Amount Approved (UGX)</label>
      <input type="number" class="form-input" id="update-amount" placeholder="Enter approved amount">
    </div>
    <div class="form-group">
      <label class="form-label">Admin Notes</label>
      <textarea class="form-textarea" id="update-notes" placeholder="Notes for the complainant..."></textarea>
    </div>
    <input type="hidden" id="modal-case-id">
    <div style="display:flex; gap:12px">
      <button class="btn btn-secondary" onclick="closeModal('caseModal')" style="flex:1">Cancel</button>
      <button class="btn btn-primary" onclick="updateCase()" style="flex:1">Update Case</button>
    </div>
  </div>
</div>

<script>
let allCases = [];

function fmtUGX(n) { return 'UGX ' + Number(n).toLocaleString(); }
function fmtDate(s) { return new Date(s).toLocaleDateString('en-UG',{day:'2-digit',month:'short',year:'numeric'}); }
function openModal(id)  { document.getElementById(id).classList.add('open'); }
function closeModal(id) { document.getElementById(id).classList.remove('open'); }

function toast(msg, type='success') {
  const t = document.createElement('div');
  t.className = `toast toast-${type}`;
  t.textContent = msg;
  document.getElementById('toast-container').appendChild(t);
  setTimeout(() => t.remove(), 4000);
}

async function loadCases() {
  const res  = await fetch('php/refund.php?action=admin_get_cases');
  const json = await res.json();
  if (!json.success) return;
  allCases = json.data;

  const filter = document.getElementById('filter-status').value;
  const cases  = filter ? allCases.filter(c => c.status === filter) : allCases;

  document.getElementById('case-count').textContent = cases.length + ' case(s)';
  const tbody = document.getElementById('cases-body');

  if (!cases.length) {
    tbody.innerHTML = '<tr><td colspan="9" style="text-align:center;color:var(--muted);padding:30px">No cases found.</td></tr>';
    return;
  }

  tbody.innerHTML = cases.map(c => `
    <tr>
      <td><span style="font-family:monospace;color:var(--accent);font-size:12px">${c.case_reference}</span></td>
      <td>
        <strong>${c.complainant_name}</strong><br>
        <span style="font-size:12px;color:var(--muted)">${c.complainant_phone}</span>
      </td>
      <td style="font-family:monospace;font-size:12px;color:var(--muted)">${c.txn_reference}</td>
      <td style="font-size:13px">${c.fraud_type}</td>
      <td style="font-weight:600;color:var(--warning)">${fmtUGX(c.amount_claimed)}</td>
      <td><span class="badge badge-${c.priority}">${c.priority}</span></td>
      <td><span class="badge badge-${c.status}">${c.status.replace('_',' ')}</span></td>
      <td style="color:var(--muted);font-size:12px">${fmtDate(c.submitted_at)}</td>
      <td>
        <button class="btn btn-secondary btn-xs" onclick="openCase(${c.case_id})">Review →</button>
      </td>
    </tr>
  `).join('');
}

function openCase(id) {
  const c = allCases.find(x => x.case_id == id);
  if (!c) return;
  document.getElementById('modal-case-id').value  = c.case_id;
  document.getElementById('modal-case-ref').textContent = '📁 ' + c.case_reference;
  document.getElementById('modal-case-sub').textContent = c.fraud_type + ' – ' + fmtUGX(c.amount_claimed);
  document.getElementById('md-name').textContent  = c.complainant_name;
  document.getElementById('md-phone').textContent = c.complainant_phone;
  document.getElementById('md-email').textContent = c.complainant_email;
  document.getElementById('md-amount').textContent = fmtUGX(c.amount_claimed);
  document.getElementById('md-desc').textContent  = c.description;
  document.getElementById('update-status').value  = c.status;
  document.getElementById('update-amount').value  = c.amount_approved || c.amount_claimed;
  document.getElementById('update-notes').value   = c.admin_notes || '';
  document.getElementById('update-alert').innerHTML = '';
  openModal('caseModal');
}

async function updateCase() {
  const body = new FormData();
  body.append('action',          'update_case');
  body.append('case_id',         document.getElementById('modal-case-id').value);
  body.append('status',          document.getElementById('update-status').value);
  body.append('amount_approved', document.getElementById('update-amount').value);
  body.append('admin_notes',     document.getElementById('update-notes').value);

  const res  = await fetch('php/refund.php', { method:'POST', body });
  const json = await res.json();
  const el   = document.getElementById('update-alert');

  if (json.success) {
    el.innerHTML = `<div class="alert alert-success">✅ ${json.message}</div>`;
    setTimeout(() => { closeModal('caseModal'); loadCases(); }, 1500);
  } else {
    el.innerHTML = `<div class="alert alert-error">⚠️ ${json.message}</div>`;
  }
}

loadCases();
</script>
</body>
</html>
