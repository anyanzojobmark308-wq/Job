<?php
// ============================================================
//  FraudGuard – Admin Fraud Alerts Page
// ============================================================
require_once 'php/config.php';
startSession(); requireLogin();
if (!isAdmin()) { header('Location: dashboard.php'); exit; }
$user = currentUser();
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Fraud Alerts – FraudGuard Admin</title>
<link href="https://fonts.googleapis.com/css2?family=Space+Grotesk:wght@300;400;500;600;700&family=Syne:wght@700;800&display=swap" rel="stylesheet">
<link rel="stylesheet" href="css/style.css">
</head>
<body>
<div class="app-layout">
  <aside class="sidebar">
    <div class="sidebar-brand"><div class="icon">🛡️</div><div class="name">Fraud<span>Guard</span></div></div>
    <div class="sidebar-user">
      <div class="avatar" style="background:linear-gradient(135deg,#ff6b35,#ff4444)"><?= strtoupper(substr($user['full_name'],0,1)) ?></div>
      <div class="uname"><?= htmlspecialchars($user['full_name']) ?></div>
      <div class="urole" style="color:var(--danger)"><?= ucfirst(str_replace('_',' ',$user['role'])) ?></div>
    </div>
    <nav class="sidebar-nav">
      <a href="admin_dashboard.php" class="nav-link"><span class="icon">📊</span> Dashboard</a>
      <a href="transactions.php" class="nav-link"><span class="icon">💳</span> All Transactions</a>
      <a href="admin_alerts.php" class="nav-link active"><span class="icon">⚠️</span> Fraud Alerts</a>
      <a href="admin_cases.php" class="nav-link"><span class="icon">📁</span> Refund Cases</a>
      <a href="admin_users.php" class="nav-link"><span class="icon">👥</span> Users</a>
      <a href="notifications.php" class="nav-link"><span class="icon">🔔</span> Notifications</a>
    </nav>
    <div class="sidebar-footer"><a href="php/auth.php?action=logout" class="nav-link"><span class="icon">🚪</span> Logout</a></div>
  </aside>

  <div class="main-content">
    <div class="topbar">
      <div class="topbar-title">⚠️ Fraud Alerts</div>
      <div class="topbar-actions">
        <select class="form-select" id="filter-severity" style="width:150px" onchange="applyFilter()">
          <option value="">All Severities</option>
          <option value="critical">Critical</option>
          <option value="high">High</option>
          <option value="medium">Medium</option>
          <option value="low">Low</option>
        </select>
        <select class="form-select" id="filter-resolved" style="width:150px" onchange="applyFilter()">
          <option value="0">Unresolved</option>
          <option value="1">Resolved</option>
          <option value="">All</option>
        </select>
      </div>
    </div>

    <div class="page-content">
      <div id="toast-container"></div>
      <div class="data-card">
        <div class="data-card-header">
          <div class="data-card-title">All Fraud Alerts</div>
          <span id="alert-count" style="font-size:13px;color:var(--muted)"></span>
        </div>
        <div style="overflow-x:auto">
          <table class="data-table">
            <thead><tr>
              <th>User</th><th>Alert Type</th><th>Severity</th>
              <th>Transaction</th><th>Amount</th><th>Location</th>
              <th>Description</th><th>Date</th><th>Action</th>
            </tr></thead>
            <tbody id="alerts-body">
              <tr><td colspan="9" style="text-align:center;color:var(--muted);padding:30px">Loading...</td></tr>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  </div>
</div>

<script>
let allAlerts = [];
function fmtUGX(n) { return 'UGX ' + Number(n).toLocaleString(); }
function fmtDate(s) { return new Date(s).toLocaleString('en-UG',{day:'2-digit',month:'short',hour:'2-digit',minute:'2-digit'}); }

async function loadAlerts() {
  const res  = await fetch('php/analytics.php?action=fraud_alerts');
  const json = await res.json();
  if (!json.success) return;
  allAlerts = json.data;
  applyFilter();
}

function applyFilter() {
  const sev = document.getElementById('filter-severity').value;
  const res = document.getElementById('filter-resolved').value;
  let filtered = allAlerts;
  if (sev) filtered = filtered.filter(a => a.severity === sev);
  if (res !== '') filtered = filtered.filter(a => String(a.is_resolved) === res);
  document.getElementById('alert-count').textContent = filtered.length + ' alert(s)';
  const tbody = document.getElementById('alerts-body');
  if (!filtered.length) {
    tbody.innerHTML = '<tr><td colspan="9" style="text-align:center;color:var(--muted);padding:30px">No alerts found.</td></tr>';
    return;
  }
  tbody.innerHTML = filtered.map(a => `
    <tr>
      <td><strong>${a.full_name}</strong><br><span style="font-size:11px;color:var(--muted)">${a.phone}</span></td>
      <td><span style="color:var(--warning)">${a.alert_type.replace(/_/g,' ')}</span></td>
      <td><span class="badge badge-${a.severity}">${a.severity}</span></td>
      <td style="font-family:monospace;color:var(--accent);font-size:11px">${a.txn_reference}</td>
      <td style="font-weight:600">${fmtUGX(a.amount)}</td>
      <td style="font-size:12px;color:var(--muted)">${a.location||'—'}</td>
      <td style="max-width:200px;font-size:12px;color:var(--muted)">${a.description}</td>
      <td style="color:var(--muted);font-size:12px">${fmtDate(a.created_at)}</td>
      <td>${!a.is_resolved
        ? `<button class="btn btn-success btn-xs" onclick="resolveAlert(${a.alert_id})">✓ Resolve</button>`
        : `<span style="color:var(--success);font-size:12px">✓ Resolved</span>`
      }</td>
    </tr>
  `).join('');
}

async function resolveAlert(id) {
  const body = new FormData(); body.append('alert_id', id);
  const res  = await fetch('php/analytics.php?action=resolve_alert', { method:'POST', body });
  const json = await res.json();
  if (json.success) loadAlerts();
}

loadAlerts();
</script>
</body>
</html>
