<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>FraudGuard API Docs</title>
<link href="https://fonts.googleapis.com/css2?family=Space+Grotesk:wght@300;400;500;600;700&family=Syne:wght@700;800&display=swap" rel="stylesheet">
<link rel="stylesheet" href="css/style.css">
<style>
body { font-family: 'Space Grotesk', sans-serif; background: var(--bg); color: var(--text); }
.api-layout { max-width: 1000px; margin: 0 auto; padding: 40px 24px; }
.api-header { text-align: center; margin-bottom: 40px; }
.api-header h1 { font-family: 'Syne', sans-serif; font-size: 36px; color: var(--white); }
.api-header h1 span { color: var(--accent); }
.endpoint-card { background: var(--surface); border: 1px solid var(--border); border-radius: 14px; margin-bottom: 20px; overflow: hidden; }
.endpoint-header { padding: 16px 20px; display: flex; align-items: center; gap: 14px; cursor: pointer; }
.method { padding: 4px 10px; border-radius: 6px; font-size: 12px; font-weight: 700; font-family: monospace; min-width: 50px; text-align: center; }
.method.get  { background: rgba(0,230,118,0.15); color: var(--success); }
.method.post { background: rgba(0,212,255,0.15); color: var(--accent); }
.endpoint-url { font-family: monospace; font-size: 14px; color: var(--text); }
.endpoint-desc { margin-left: auto; font-size: 13px; color: var(--muted); }
.endpoint-body { padding: 20px; border-top: 1px solid var(--border); display: none; }
.endpoint-body.open { display: block; }
.code-block { background: var(--surface2); border: 1px solid var(--border); border-radius: 10px; padding: 16px; font-family: monospace; font-size: 13px; line-height: 1.6; overflow-x: auto; margin: 12px 0; white-space: pre; color: var(--accent); }
.section-label { font-size: 11px; text-transform: uppercase; letter-spacing: 0.5px; color: var(--muted); margin-bottom: 8px; font-weight: 600; }
.key-card { background: var(--surface2); border: 1px solid var(--border); border-radius: 10px; padding: 16px; margin-bottom: 12px; }
.key-name { font-weight: 600; margin-bottom: 4px; }
.key-val { font-family: monospace; color: var(--accent); font-size: 13px; }
.test-section { background: var(--surface2); border-radius: 10px; padding: 16px; margin-top: 14px; }
.test-btn { background: var(--grad); border: none; color: #000; padding: 8px 18px; border-radius: 8px; font-family: 'Space Grotesk', sans-serif; font-weight: 700; cursor: pointer; font-size: 13px; }
.test-result { background: var(--surface); border: 1px solid var(--border); border-radius: 8px; padding: 14px; margin-top: 12px; font-family: monospace; font-size: 12px; color: var(--success); line-height: 1.6; display: none; white-space: pre-wrap; max-height: 300px; overflow-y: auto; }
</style>
</head>
<body>
<div class="api-layout">

  <div class="api-header">
    <div style="font-size:40px; margin-bottom:10px">🛡️</div>
    <h1>Fraud<span>Guard</span> API</h1>
    <p style="color:var(--muted); margin-top:8px">REST API for integration with mobile apps and third-party systems</p>
    <div style="margin-top:16px; display:inline-block; background:rgba(0,230,118,0.1); border:1px solid rgba(0,230,118,0.3); color:var(--success); padding:6px 18px; border-radius:20px; font-size:13px">
      ● API Online — v1.0.0
    </div>
  </div>

  <!-- Base URL -->
  <div class="data-card" style="margin-bottom:28px">
    <div class="data-card-header"><div class="data-card-title">🌐 Base URL</div></div>
    <div style="padding:20px">
      <div class="code-block">http://localhost/fraudguard/api.php</div>
      <div style="font-size:13px; color:var(--muted); margin-top:8px">
        Replace <strong style="color:var(--accent)">localhost</strong> with your domain when deploying live e.g. <strong style="color:var(--accent)">https://yoursite.com/fraudguard/api.php</strong>
      </div>
    </div>
  </div>

  <!-- API Keys -->
  <div class="data-card" style="margin-bottom:28px">
    <div class="data-card-header"><div class="data-card-title">🔑 API Keys</div></div>
    <div style="padding:20px">
      <div style="font-size:13px; color:var(--muted); margin-bottom:16px">
        Pass your API key in every request using the <code style="color:var(--accent)">X-API-Key</code> header.
      </div>
      <div class="key-card">
        <div class="key-name">Admin Key <span class="badge badge-flagged" style="font-size:10px">Full Access</span></div>
        <div class="key-val">FG-API-ADMIN-2026</div>
      </div>
      <div class="key-card">
        <div class="key-name">Mobile App Key <span class="badge badge-completed" style="font-size:10px">Customer Access</span></div>
        <div class="key-val">FG-API-MOBILE-2026</div>
      </div>
      <div class="key-card">
        <div class="key-name">Partner Key <span class="badge badge-pending" style="font-size:10px">Partner Access</span></div>
        <div class="key-val">FG-API-PARTNER-2026</div>
      </div>
      <div style="background:rgba(255,179,0,0.08); border:1px solid rgba(255,179,0,0.2); border-radius:8px; padding:12px; font-size:13px; color:var(--warning); margin-top:12px">
        ⚠️ In a live system, store API keys in a database and rotate them regularly. Never expose admin keys in client-side code.
      </div>
    </div>
  </div>

  <!-- Endpoints -->
  <div style="font-size:18px; font-weight:700; margin-bottom:16px">📋 Endpoints</div>

  <!-- Status -->
  <div class="endpoint-card">
    <div class="endpoint-header" onclick="toggle('ep-status')">
      <span class="method get">GET</span>
      <span class="endpoint-url">?endpoint=status</span>
      <span class="endpoint-desc">Check if API is online</span>
    </div>
    <div class="endpoint-body" id="ep-status">
      <div class="section-label">Example Request</div>
      <div class="code-block">GET http://localhost/fraudguard/api.php?endpoint=status
X-API-Key: FG-API-MOBILE-2026</div>
      <div class="section-label">Example Response</div>
      <div class="code-block">{
  "success": true,
  "system": "FraudGuard API",
  "version": "1.0.0",
  "status": "online",
  "timestamp": "2026-01-15 10:30:00"
}</div>
      <div class="test-section">
        <div class="section-label">Live Test</div>
        <button class="test-btn" onclick="testAPI('?endpoint=status', 'GET', null, 'res-status')">▶ Run Test</button>
        <div class="test-result" id="res-status"></div>
      </div>
    </div>
  </div>

  <!-- Login -->
  <div class="endpoint-card">
    <div class="endpoint-header" onclick="toggle('ep-login')">
      <span class="method post">POST</span>
      <span class="endpoint-url">?endpoint=login</span>
      <span class="endpoint-desc">Login and get user info</span>
    </div>
    <div class="endpoint-body" id="ep-login">
      <div class="section-label">Request Body (JSON)</div>
      <div class="code-block">{
  "email": "joel@example.com",
  "password": "password123"
}</div>
      <div class="section-label">Example Response</div>
      <div class="code-block">{
  "success": true,
  "token": "Mn...(session token)",
  "user": {
    "user_id": 2,
    "full_name": "Joel Manana",
    "email": "joel@example.com",
    "role": "customer",
    "account_no": "FG-2025-0001",
    "balance": 2500000,
    "status": "active"
  }
}</div>
      <div class="test-section">
        <div class="section-label">Live Test</div>
        <button class="test-btn" onclick="testAPI('?endpoint=login','POST',{email:'joel@example.com',password:'password123'},'res-login')">▶ Run Test</button>
        <div class="test-result" id="res-login"></div>
      </div>
    </div>
  </div>

  <!-- Balance -->
  <div class="endpoint-card">
    <div class="endpoint-header" onclick="toggle('ep-balance')">
      <span class="method get">GET</span>
      <span class="endpoint-url">?endpoint=balance&user_id={id}</span>
      <span class="endpoint-desc">Get account balance</span>
    </div>
    <div class="endpoint-body" id="ep-balance">
      <div class="section-label">Parameters</div>
      <div class="code-block">user_id  (required)  — the user's ID number</div>
      <div class="section-label">Example Response</div>
      <div class="code-block">{
  "success": true,
  "account_no": "FG-2025-0001",
  "balance": 2500000,
  "currency": "UGX",
  "timestamp": "2026-01-15 10:30:00"
}</div>
      <div class="test-section">
        <div class="section-label">Live Test (User ID: 2)</div>
        <button class="test-btn" onclick="testAPI('?endpoint=balance&user_id=2','GET',null,'res-balance')">▶ Run Test</button>
        <div class="test-result" id="res-balance"></div>
      </div>
    </div>
  </div>

  <!-- Transfer -->
  <div class="endpoint-card">
    <div class="endpoint-header" onclick="toggle('ep-transfer')">
      <span class="method post">POST</span>
      <span class="endpoint-url">?endpoint=transfer</span>
      <span class="endpoint-desc">Submit a money transfer</span>
    </div>
    <div class="endpoint-body" id="ep-transfer">
      <div class="section-label">Request Body (JSON)</div>
      <div class="code-block">{
  "sender_id": 2,
  "receiver_account": "FG-2025-0002",
  "amount": 150000,
  "channel": "mobile_money",
  "location": "Kampala, UG",
  "device_id": "MOBILE-APP-001"
}</div>
      <div class="section-label">Example Response (Success)</div>
      <div class="code-block">{
  "success": true,
  "reference": "TXN-2026-AB1234",
  "status": "completed",
  "fraud_score": 8.5,
  "fraud_action": "allow",
  "flags": [],
  "amount": 150000,
  "currency": "UGX",
  "receiver": "Melissa Nakuya",
  "timestamp": "2026-01-15 10:30:00"
}</div>
      <div class="section-label">Example Response (Blocked)</div>
      <div class="code-block">{
  "success": false,
  "reference": "TXN-2026-XY9999",
  "status": "blocked",
  "fraud_score": 90,
  "fraud_action": "block",
  "flags": [
    "Amount exceeds UGX 20M block threshold",
    "Transaction from unrecognised device"
  ]
}</div>
      <div class="test-section">
        <div class="section-label">Live Test — Transfer UGX 50,000</div>
        <button class="test-btn" onclick="testAPI('?endpoint=transfer','POST',{sender_id:2,receiver_account:'FG-2025-0002',amount:50000,channel:'mobile_money',location:'Kampala, UG'},'res-transfer')">▶ Run Test</button>
        <div class="test-result" id="res-transfer"></div>
      </div>
    </div>
  </div>

  <!-- Transactions -->
  <div class="endpoint-card">
    <div class="endpoint-header" onclick="toggle('ep-txns')">
      <span class="method get">GET</span>
      <span class="endpoint-url">?endpoint=transactions&user_id={id}</span>
      <span class="endpoint-desc">Get transaction history</span>
    </div>
    <div class="endpoint-body" id="ep-txns">
      <div class="section-label">Parameters</div>
      <div class="code-block">user_id  (required)  — user ID
limit    (optional) — max records, default 20, max 100</div>
      <div class="test-section">
        <div class="section-label">Live Test</div>
        <button class="test-btn" onclick="testAPI('?endpoint=transactions&user_id=2&limit=5','GET',null,'res-txns')">▶ Run Test</button>
        <div class="test-result" id="res-txns"></div>
      </div>
    </div>
  </div>

  <!-- Report Fraud -->
  <div class="endpoint-card">
    <div class="endpoint-header" onclick="toggle('ep-fraud')">
      <span class="method post">POST</span>
      <span class="endpoint-url">?endpoint=report_fraud</span>
      <span class="endpoint-desc">Report a fraud case</span>
    </div>
    <div class="endpoint-body" id="ep-fraud">
      <div class="section-label">Request Body (JSON)</div>
      <div class="code-block">{
  "user_id": 2,
  "txn_reference": "TXN-2025-000003",
  "fraud_type": "Unauthorized Transfer",
  "amount_claimed": 8500000,
  "description": "I did not authorise this transaction."
}</div>
      <div class="section-label">Example Response</div>
      <div class="code-block">{
  "success": true,
  "case_reference": "CASE-2026-AB1234",
  "priority": "high",
  "message": "Fraud case submitted. An officer will review it shortly.",
  "amount_claimed": 8500000,
  "currency": "UGX"
}</div>
    </div>
  </div>

  <!-- Stats -->
  <div class="endpoint-card">
    <div class="endpoint-header" onclick="toggle('ep-stats')">
      <span class="method get">GET</span>
      <span class="endpoint-url">?endpoint=stats</span>
      <span class="endpoint-desc">System statistics (admin key only)</span>
    </div>
    <div class="endpoint-body" id="ep-stats">
      <div class="test-section">
        <div class="section-label">Live Test (Admin Key)</div>
        <button class="test-btn" onclick="testAPI('?endpoint=stats','GET',null,'res-stats','FG-API-ADMIN-2026')">▶ Run Test</button>
        <div class="test-result" id="res-stats"></div>
      </div>
    </div>
  </div>

  <!-- How to use from JavaScript -->
  <div class="data-card" style="margin-top:28px">
    <div class="data-card-header"><div class="data-card-title">💻 How to Call the API from JavaScript</div></div>
    <div style="padding:20px">
      <div class="section-label">GET Request Example</div>
      <div class="code-block">// Check account balance
const response = await fetch(
  'http://localhost/fraudguard/api.php?endpoint=balance&user_id=2',
  {
    method: 'GET',
    headers: {
      'X-API-Key': 'FG-API-MOBILE-2026'
    }
  }
);
const data = await response.json();
console.log(data.balance); // 2500000</div>

      <div class="section-label" style="margin-top:16px">POST Request Example</div>
      <div class="code-block">// Submit a transfer
const response = await fetch(
  'http://localhost/fraudguard/api.php?endpoint=transfer',
  {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'X-API-Key': 'FG-API-MOBILE-2026'
    },
    body: JSON.stringify({
      sender_id: 2,
      receiver_account: 'FG-2025-0002',
      amount: 150000,
      channel: 'mobile_money',
      location: 'Kampala, UG'
    })
  }
);
const result = await response.json();
if (result.success) {
  console.log('Transfer ref:', result.reference);
} else {
  console.log('Blocked:', result.flags);
}</div>

      <div class="section-label" style="margin-top:16px">PHP cURL Example</div>
      <div class="code-block">$ch = curl_init('http://localhost/fraudguard/api.php?endpoint=balance&user_id=2');
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_HTTPHEADER, ['X-API-Key: FG-API-MOBILE-2026']);
$response = json_decode(curl_exec($ch), true);
echo $response['balance']; // 2500000</div>
    </div>
  </div>

  <div style="text-align:center; margin-top:32px; color:var(--muted); font-size:13px">
    FraudGuard API v1.0 — Kampala International University 2026<br>
    <a href="index.php" style="color:var(--accent)">← Back to System</a>
  </div>

</div>

<script>
function toggle(id) {
  const el = document.getElementById(id);
  el.classList.toggle('open');
}

async function testAPI(endpoint, method, body, resultId, key = 'FG-API-MOBILE-2026') {
  const resultEl = document.getElementById(resultId);
  resultEl.style.display = 'block';
  resultEl.style.color   = 'var(--muted)';
  resultEl.textContent   = 'Running...';

  try {
    const opts = {
      method,
      headers: { 'X-API-Key': key, 'Content-Type': 'application/json' }
    };
    if (body) opts.body = JSON.stringify(body);

    const res  = await fetch('api.php' + endpoint, opts);
    const json = await res.json();
    resultEl.textContent = JSON.stringify(json, null, 2);
    resultEl.style.color = json.success ? 'var(--success)' : 'var(--danger)';
  } catch (e) {
    resultEl.textContent = 'Error: ' + e.message;
    resultEl.style.color = 'var(--danger)';
  }
}
</script>
</body>
</html>
