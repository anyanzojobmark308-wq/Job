-- ============================================================
--  FraudGuard – Add deposit_requests table
--  Run this in phpMyAdmin SQL tab if not already added
-- ============================================================
USE fraudguard_db;

CREATE TABLE IF NOT EXISTS deposit_requests (
    deposit_id        INT AUTO_INCREMENT PRIMARY KEY,
    user_id           INT             NOT NULL,
    deposit_reference VARCHAR(50) UNIQUE NOT NULL,
    amount            DECIMAL(15,2)   NOT NULL,
    amount_approved   DECIMAL(15,2)   DEFAULT 0.00,
    payment_method    VARCHAR(100)    NOT NULL,
    payment_ref       VARCHAR(100),
    notes             TEXT,
    status            ENUM('pending','approved','rejected') DEFAULT 'pending',
    admin_notes       TEXT,
    approved_by       INT,
    approved_at       DATETIME,
    created_at        DATETIME        DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id)     REFERENCES users(user_id),
    FOREIGN KEY (approved_by) REFERENCES users(user_id)
);
