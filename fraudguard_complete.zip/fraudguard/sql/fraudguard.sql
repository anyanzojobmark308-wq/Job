-- ============================================================
--  FraudGuard Database Schema
--  Financial Fraud Detection, Prevention & Refund Support
--  Kampala International University – 2026
-- ============================================================

CREATE DATABASE IF NOT EXISTS fraudguard_db;
USE fraudguard_db;

-- ─────────────────────────────────────────────
-- USERS TABLE
-- ─────────────────────────────────────────────
CREATE TABLE users (
    user_id       INT AUTO_INCREMENT PRIMARY KEY,
    full_name     VARCHAR(150)        NOT NULL,
    email         VARCHAR(150) UNIQUE NOT NULL,
    phone         VARCHAR(20)         NOT NULL,
    password_hash VARCHAR(255)        NOT NULL,
    role          ENUM('customer','admin','agent','fraud_officer') DEFAULT 'customer',
    account_no    VARCHAR(20) UNIQUE,
    balance       DECIMAL(15,2)       DEFAULT 0.00,
    status        ENUM('active','suspended','locked') DEFAULT 'active',
    created_at    DATETIME            DEFAULT CURRENT_TIMESTAMP,
    last_login    DATETIME
);

-- ─────────────────────────────────────────────
-- TRANSACTIONS TABLE
-- ─────────────────────────────────────────────
CREATE TABLE transactions (
    txn_id          INT AUTO_INCREMENT PRIMARY KEY,
    sender_id       INT             NOT NULL,
    receiver_id     INT,
    txn_reference   VARCHAR(50) UNIQUE NOT NULL,
    txn_type        ENUM('transfer','payment','withdrawal','deposit') NOT NULL,
    amount          DECIMAL(15,2)   NOT NULL,
    currency        VARCHAR(5)      DEFAULT 'UGX',
    channel         ENUM('mobile_money','online_banking','atm','agent') DEFAULT 'mobile_money',
    device_id       VARCHAR(100),
    ip_address      VARCHAR(45),
    location        VARCHAR(150),
    status          ENUM('pending','completed','flagged','blocked','refunded') DEFAULT 'pending',
    fraud_score     DECIMAL(5,2)    DEFAULT 0.00,  -- 0-100
    created_at      DATETIME        DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (sender_id)   REFERENCES users(user_id),
    FOREIGN KEY (receiver_id) REFERENCES users(user_id)
);

-- ─────────────────────────────────────────────
-- FRAUD ALERTS TABLE
-- ─────────────────────────────────────────────
CREATE TABLE fraud_alerts (
    alert_id        INT AUTO_INCREMENT PRIMARY KEY,
    txn_id          INT             NOT NULL,
    user_id         INT             NOT NULL,
    alert_type      ENUM('unusual_amount','location_change','high_frequency',
                         'sim_swap','device_change','suspicious_pattern') NOT NULL,
    severity        ENUM('low','medium','high','critical') DEFAULT 'medium',
    description     TEXT,
    is_resolved     TINYINT(1)      DEFAULT 0,
    resolved_by     INT,
    resolved_at     DATETIME,
    created_at      DATETIME        DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (txn_id)      REFERENCES transactions(txn_id),
    FOREIGN KEY (user_id)     REFERENCES users(user_id),
    FOREIGN KEY (resolved_by) REFERENCES users(user_id)
);

-- ─────────────────────────────────────────────
-- REFUND CASES TABLE
-- ─────────────────────────────────────────────
CREATE TABLE refund_cases (
    case_id         INT AUTO_INCREMENT PRIMARY KEY,
    txn_id          INT             NOT NULL,
    complainant_id  INT             NOT NULL,
    case_reference  VARCHAR(50) UNIQUE NOT NULL,
    fraud_type      VARCHAR(100),
    description     TEXT            NOT NULL,
    amount_claimed  DECIMAL(15,2)   NOT NULL,
    amount_approved DECIMAL(15,2)   DEFAULT 0.00,
    status          ENUM('submitted','under_review','approved','rejected','refunded') DEFAULT 'submitted',
    priority        ENUM('low','medium','high') DEFAULT 'medium',
    assigned_to     INT,
    admin_notes     TEXT,
    submitted_at    DATETIME        DEFAULT CURRENT_TIMESTAMP,
    updated_at      DATETIME        ON UPDATE CURRENT_TIMESTAMP,
    resolved_at     DATETIME,
    FOREIGN KEY (txn_id)         REFERENCES transactions(txn_id),
    FOREIGN KEY (complainant_id) REFERENCES users(user_id),
    FOREIGN KEY (assigned_to)    REFERENCES users(user_id)
);

-- ─────────────────────────────────────────────
-- FRAUD RULES TABLE
-- ─────────────────────────────────────────────
CREATE TABLE fraud_rules (
    rule_id         INT AUTO_INCREMENT PRIMARY KEY,
    rule_name       VARCHAR(100)    NOT NULL,
    rule_type       ENUM('amount_threshold','frequency_limit','location_mismatch',
                         'time_restriction','device_check') NOT NULL,
    threshold_value DECIMAL(15,2),
    frequency_limit INT,
    time_window     INT,            -- in minutes
    action          ENUM('alert','block','flag') DEFAULT 'alert',
    is_active       TINYINT(1)      DEFAULT 1,
    created_at      DATETIME        DEFAULT CURRENT_TIMESTAMP
);

-- ─────────────────────────────────────────────
-- AUDIT LOGS TABLE
-- ─────────────────────────────────────────────
CREATE TABLE audit_logs (
    log_id          INT AUTO_INCREMENT PRIMARY KEY,
    user_id         INT,
    action          VARCHAR(200)    NOT NULL,
    module          VARCHAR(50),
    ip_address      VARCHAR(45),
    details         TEXT,
    created_at      DATETIME        DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(user_id)
);

-- ─────────────────────────────────────────────
-- NOTIFICATIONS TABLE
-- ─────────────────────────────────────────────
CREATE TABLE notifications (
    notif_id        INT AUTO_INCREMENT PRIMARY KEY,
    user_id         INT             NOT NULL,
    title           VARCHAR(200)    NOT NULL,
    message         TEXT            NOT NULL,
    type            ENUM('alert','info','warning','success') DEFAULT 'info',
    is_read         TINYINT(1)      DEFAULT 0,
    created_at      DATETIME        DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(user_id)
);

-- ─────────────────────────────────────────────
-- SEED DATA – Default Rules
-- ─────────────────────────────────────────────
INSERT INTO fraud_rules (rule_name, rule_type, threshold_value, frequency_limit, time_window, action) VALUES
('High Amount Alert',    'amount_threshold',  5000000, NULL, NULL, 'alert'),
('Critical Amount Block','amount_threshold', 20000000, NULL, NULL, 'block'),
('Rapid Transfers',      'frequency_limit',  NULL,    5,   10,  'flag'),
('Unusual Hour',         'time_restriction', NULL,    NULL, NULL, 'alert');

-- ─────────────────────────────────────────────
-- SEED DATA – Demo Users
-- ─────────────────────────────────────────────
-- Passwords are hashed with password_hash('password123', PASSWORD_BCRYPT)
INSERT INTO users (full_name, email, phone, password_hash, role, account_no, balance) VALUES
('Admin User',   'admin@fraudguard.ug',  '0700000001', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'admin',         'FG-ADMIN-001', 0.00),
('Joel Manana',  'joel@example.com',     '0701234567', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'customer',      'FG-2025-0001', 2500000.00),
('Melissa Nakuya','melissa@example.com', '0712345678', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'customer',      'FG-2025-0002', 1800000.00),
('Fraud Officer','officer@fraudguard.ug','0700000002', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'fraud_officer', 'FG-OFFI-001',  0.00);

-- ─────────────────────────────────────────────
-- SEED DATA – Sample Transactions
-- ─────────────────────────────────────────────
INSERT INTO transactions (sender_id, receiver_id, txn_reference, txn_type, amount, channel, device_id, ip_address, location, status, fraud_score) VALUES
(2, 3, 'TXN-2025-000001', 'transfer',   150000,   'mobile_money',   'DEV-A1', '41.75.10.2',  'Kampala, UG',  'completed', 5.0),
(3, 2, 'TXN-2025-000002', 'payment',    750000,   'online_banking', 'DEV-B2', '41.75.10.5',  'Entebbe, UG',  'completed', 12.0),
(2, 3, 'TXN-2025-000003', 'transfer',   8500000,  'mobile_money',   'DEV-X9', '197.21.5.10', 'Lagos, NG',    'flagged',   78.5),
(3, 2, 'TXN-2025-000004', 'withdrawal', 500000,   'atm',            'DEV-B2', '41.75.10.5',  'Jinja, UG',    'completed', 8.0),
(2, 3, 'TXN-2025-000005', 'transfer',   22000000, 'online_banking', 'DEV-Z3', '102.89.1.55', 'Nairobi, KE',  'blocked',   95.0);

-- ─────────────────────────────────────────────
-- SEED DATA – Sample Fraud Alerts
-- ─────────────────────────────────────────────
INSERT INTO fraud_alerts (txn_id, user_id, alert_type, severity, description) VALUES
(3, 2, 'location_change',    'high',     'Transaction initiated from Nigeria – unusual for this account.'),
(5, 2, 'unusual_amount',     'critical', 'Transfer of UGX 22,000,000 exceeds account threshold. Blocked automatically.');

-- ─────────────────────────────────────────────
-- SEED DATA – Sample Refund Case
-- ─────────────────────────────────────────────
INSERT INTO refund_cases (txn_id, complainant_id, case_reference, fraud_type, description, amount_claimed, status, priority) VALUES
(3, 2, 'CASE-2025-0001', 'Unauthorized Transfer',
 'I did not authorize this transfer of UGX 8,500,000. My phone was lost and someone used it.',
  8500000, 'under_review', 'high');
