<?php
// admin_transactions.php – redirects to shared transactions.php (admin view)
require_once 'php/config.php';
startSession(); requireLogin();
if (!isAdmin()) { header('Location: dashboard.php'); exit; }
// transactions.php handles both admin and customer views via isAdmin()
header('Location: transactions.php');
exit;
