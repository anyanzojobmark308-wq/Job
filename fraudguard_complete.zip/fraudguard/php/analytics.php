<?php
// ============================================================
//  FraudGuard – Analytics & Stats API (analytics.php)
// ============================================================
require_once __DIR__ . '/config.php';
startSession();
requireLogin();

$action = $_GET['action'] ?? '';
$db     = getDB();

// ─── DASHBOARD STATS ──────────────────────────────────────
if ($action === 'dashboard_stats') {
    $uid = currentUser()['user_id'];

    if (isAdmin()) {
        // Admin stats
        $stats = [];

        $stats['total_transactions'] = (int)$db->query("SELECT COUNT(*) FROM transactions")->fetchColumn();
        $stats['flagged_today']   = (int)$db->query("SELECT COUNT(*) FROM transactions WHERE status IN ('flagged','blocked') AND DATE(created_at)=CURDATE()")->fetchColumn();
        $stats['open_cases']      = (int)$db->query("SELECT COUNT(*) FROM refund_cases WHERE status IN ('submitted','under_review')")->fetchColumn();
        $stats['total_users']     = (int)$db->query("SELECT COUNT(*) FROM users WHERE role='customer'")->fetchColumn();
        $stats['blocked_today']   = (int)$db->query("SELECT COUNT(*) FROM transactions WHERE status='blocked' AND DATE(created_at)=CURDATE()")->fetchColumn();
        $stats['refund_pending']  = (int)$db->query("SELECT COUNT(*) FROM refund_cases WHERE status='approved'")->fetchColumn();
        $stats['total_alerts']    = (int)$db->query("SELECT COUNT(*) FROM fraud_alerts WHERE is_resolved=0")->fetchColumn();

        // Transaction volume last 7 days
        $volStmt = $db->query("
            SELECT DATE(created_at) as txn_date, COUNT(*) as count, SUM(amount) as volume
            FROM transactions
            WHERE created_at >= DATE_SUB(NOW(), INTERVAL 7 DAY)
            GROUP BY DATE(created_at) ORDER BY txn_date
        ");
        $stats['volume_chart'] = $volStmt->fetchAll();

        // Fraud by type
        $typeStmt = $db->query("
            SELECT alert_type, COUNT(*) as count FROM fraud_alerts GROUP BY alert_type
        ");
        $stats['fraud_by_type'] = $typeStmt->fetchAll();

        // Recent alerts
        $alertStmt = $db->query("
            SELECT fa.*, u.full_name, t.txn_reference, t.amount
            FROM fraud_alerts fa
            JOIN users u ON fa.user_id = u.user_id
            JOIN transactions t ON fa.txn_id = t.txn_id
            ORDER BY fa.created_at DESC LIMIT 10
        ");
        $stats['recent_alerts'] = $alertStmt->fetchAll();

    } else {
        // Customer stats
        $stats = [];
        $bal = $db->prepare("SELECT balance, account_no FROM users WHERE user_id=?");
        $bal->execute([$uid]); $acct = $bal->fetch();
        $stats['balance']     = $acct['balance'];
        $stats['account_no']  = $acct['account_no'];
        $stats['total_sent']  = (float)$db->prepare("SELECT COALESCE(SUM(amount),0) FROM transactions WHERE sender_id=? AND status='completed'")->execute([$uid]) ? $db->prepare("SELECT COALESCE(SUM(amount),0) FROM transactions WHERE sender_id=? AND status='completed'")->execute([$uid]) : 0;
        $cntStmt = $db->prepare("SELECT COUNT(*) FROM transactions WHERE sender_id=? AND status='completed'"); $cntStmt->execute([$uid]);
        $stats['txn_count']  = (int)$cntStmt->fetchColumn();
        $caseStmt = $db->prepare("SELECT COUNT(*) FROM refund_cases WHERE complainant_id=?"); $caseStmt->execute([$uid]);
        $stats['open_cases'] = (int)$caseStmt->fetchColumn();
        $notifStmt = $db->prepare("SELECT COUNT(*) FROM notifications WHERE user_id=? AND is_read=0"); $notifStmt->execute([$uid]);
        $stats['unread_notif'] = (int)$notifStmt->fetchColumn();

        // Recent 5 transactions
        $txnStmt = $db->prepare("
            SELECT t.*, u.full_name as receiver_name
            FROM transactions t LEFT JOIN users u ON t.receiver_id=u.user_id
            WHERE t.sender_id=? OR t.receiver_id=?
            ORDER BY t.created_at DESC LIMIT 5
        ");
        $txnStmt->execute([$uid,$uid]);
        $stats['recent_transactions'] = $txnStmt->fetchAll();
    }

    echo json_encode(['success'=>true,'data'=>$stats]);
    exit;
}

// ─── GET NOTIFICATIONS ────────────────────────────────────
if ($action === 'notifications') {
    $uid  = currentUser()['user_id'];
    $stmt = $db->prepare("SELECT * FROM notifications WHERE user_id=? ORDER BY created_at DESC LIMIT 20");
    $stmt->execute([$uid]);
    // Mark as read
    $db->prepare("UPDATE notifications SET is_read=1 WHERE user_id=?")->execute([$uid]);
    echo json_encode(['success'=>true,'data'=>$stmt->fetchAll()]);
    exit;
}

// ─── FRAUD ALERTS LIST (admin) ─────────────────────────────
if ($action === 'fraud_alerts' && isAdmin()) {
    $stmt = $db->query("
        SELECT fa.*, u.full_name, u.phone, t.txn_reference, t.amount, t.location
        FROM fraud_alerts fa
        JOIN users u ON fa.user_id = u.user_id
        JOIN transactions t ON fa.txn_id = t.txn_id
        ORDER BY fa.created_at DESC LIMIT 100
    ");
    echo json_encode(['success'=>true,'data'=>$stmt->fetchAll()]);
    exit;
}

// ─── RESOLVE ALERT (admin) ────────────────────────────────
if ($action === 'resolve_alert' && isAdmin()) {
    $alertId = (int)($_POST['alert_id'] ?? 0);
    $uid     = currentUser()['user_id'];
    $db->prepare("UPDATE fraud_alerts SET is_resolved=1, resolved_by=?, resolved_at=NOW() WHERE alert_id=?")
       ->execute([$uid, $alertId]);
    echo json_encode(['success'=>true,'message'=>'Alert resolved.']);
    exit;
}

echo json_encode(['success'=>false,'message'=>'Invalid action.']);
