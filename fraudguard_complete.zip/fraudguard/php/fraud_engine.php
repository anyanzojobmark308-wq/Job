<?php
// ============================================================
//  FraudGuard – Fraud Detection Engine
// ============================================================
require_once __DIR__ . '/config.php';

class FraudDetector {

    private PDO $db;

    public function __construct() {
        $this->db = getDB();
    }

    // ─────────────────────────────────────────────────────
    // MAIN ENTRY: Score a transaction and act on it
    // Returns: ['score'=>float, 'action'=>string, 'flags'=>array]
    // ─────────────────────────────────────────────────────
    public function evaluate(array $txn): array {
        $score  = 0.0;
        $flags  = [];

        // 1. Unusual amount check
        $amountResult = $this->checkAmount($txn['sender_id'], $txn['amount']);
        $score += $amountResult['score'];
        if ($amountResult['flag']) $flags[] = $amountResult['flag'];

        // 2. Transaction frequency check (rapid transfers)
        $freqResult = $this->checkFrequency($txn['sender_id']);
        $score += $freqResult['score'];
        if ($freqResult['flag']) $flags[] = $freqResult['flag'];

        // 3. Location / IP check
        $locResult = $this->checkLocation($txn['sender_id'], $txn['location'] ?? '', $txn['ip_address'] ?? '');
        $score += $locResult['score'];
        if ($locResult['flag']) $flags[] = $locResult['flag'];

        // 4. Unusual hour check (midnight – 5 AM EAT)
        $hourResult = $this->checkHour();
        $score += $hourResult['score'];
        if ($hourResult['flag']) $flags[] = $hourResult['flag'];

        // 5. Device change check
        $devResult = $this->checkDevice($txn['sender_id'], $txn['device_id'] ?? '');
        $score += $devResult['score'];
        if ($devResult['flag']) $flags[] = $devResult['flag'];

        // Cap score at 100
        $score = min(100.0, round($score, 2));

        // Determine action
        $action = 'allow';
        $severity = 'low';
        if ($score >= 80) { $action = 'block';  $severity = 'critical'; }
        elseif ($score >= 60) { $action = 'flag'; $severity = 'high'; }
        elseif ($score >= 35) { $action = 'alert'; $severity = 'medium'; }

        return compact('score', 'action', 'severity', 'flags');
    }

    // ─────────────────────────────────────────────────────
    // 1. AMOUNT CHECK
    // ─────────────────────────────────────────────────────
    private function checkAmount(int $userId, float $amount): array {
        // Get user's average transaction
        $stmt = $this->db->prepare("
            SELECT AVG(amount) as avg_amt, MAX(amount) as max_amt
            FROM transactions WHERE sender_id = ? AND status = 'completed'
        ");
        $stmt->execute([$userId]);
        $stats = $stmt->fetch();

        $score = 0;
        $flag  = null;

        if ($amount >= 20000000) {
            $score = 40; $flag = ['type'=>'unusual_amount','detail'=>'Amount exceeds UGX 20M block threshold'];
        } elseif ($amount >= 5000000) {
            $score = 20; $flag = ['type'=>'unusual_amount','detail'=>'Amount exceeds UGX 5M alert threshold'];
        } elseif ($stats['avg_amt'] && $amount > ($stats['avg_amt'] * 5)) {
            $score = 15; $flag = ['type'=>'unusual_amount','detail'=>'Amount is 5× above your average'];
        }

        return ['score'=>$score, 'flag'=>$flag];
    }

    // ─────────────────────────────────────────────────────
    // 2. FREQUENCY CHECK – >5 transactions in 10 minutes
    // ─────────────────────────────────────────────────────
    private function checkFrequency(int $userId): array {
        $stmt = $this->db->prepare("
            SELECT COUNT(*) as cnt FROM transactions
            WHERE sender_id = ?
              AND created_at >= DATE_SUB(NOW(), INTERVAL 10 MINUTE)
        ");
        $stmt->execute([$userId]);
        $cnt = (int)$stmt->fetchColumn();

        $score = 0; $flag = null;
        if ($cnt >= 5) {
            $score = 30;
            $flag = ['type'=>'high_frequency','detail'=>"$cnt transactions in the last 10 minutes"];
        }
        return ['score'=>$score, 'flag'=>$flag];
    }

    // ─────────────────────────────────────────────────────
    // 3. LOCATION CHECK – flag non-Ugandan IPs / locations
    // ─────────────────────────────────────────────────────
    private function checkLocation(int $userId, string $location, string $ip): array {
        $score = 0; $flag = null;

        // Simple heuristic: check if location contains 'UG' or known Ugandan cities
        $ugCities = ['kampala','entebbe','jinja','gulu','mbarara','mbale','arua','fort portal'];
        $locLower = strtolower($location);
        $isUganda = str_contains($locLower, 'ug') || str_contains($locLower, 'uganda');
        foreach ($ugCities as $city) {
            if (str_contains($locLower, $city)) { $isUganda = true; break; }
        }

        if (!$isUganda && !empty($location)) {
            // Check last known location
            $stmt = $this->db->prepare("
                SELECT location FROM transactions
                WHERE sender_id = ? AND status = 'completed'
                ORDER BY created_at DESC LIMIT 1
            ");
            $stmt->execute([$userId]);
            $lastLoc = $stmt->fetchColumn();

            if ($lastLoc) {
                $score = 25;
                $flag = ['type'=>'location_change','detail'=>"Transaction from $location (last known: $lastLoc)"];
            }
        }
        return ['score'=>$score, 'flag'=>$flag];
    }

    // ─────────────────────────────────────────────────────
    // 4. HOUR CHECK – midnight to 5 AM EAT
    // ─────────────────────────────────────────────────────
    private function checkHour(): array {
        $hour = (int)date('G'); // EAT = UTC+3 (adjust if server is UTC)
        $score = 0; $flag = null;
        if ($hour >= 0 && $hour < 5) {
            $score = 10;
            $flag = ['type'=>'suspicious_pattern','detail'=>'Transaction at unusual hour (' . date('H:i') . ' EAT)'];
        }
        return ['score'=>$score, 'flag'=>$flag];
    }

    // ─────────────────────────────────────────────────────
    // 5. DEVICE CHECK – new/unknown device
    // ─────────────────────────────────────────────────────
    private function checkDevice(int $userId, string $deviceId): array {
        $score = 0; $flag = null;
        if (empty($deviceId)) return ['score'=>5, 'flag'=>['type'=>'device_change','detail'=>'Unknown device']];

        $stmt = $this->db->prepare("
            SELECT COUNT(*) FROM transactions
            WHERE sender_id = ? AND device_id = ? AND status = 'completed'
        ");
        $stmt->execute([$userId, $deviceId]);
        $known = (int)$stmt->fetchColumn();

        if ($known === 0) {
            $score = 15;
            $flag = ['type'=>'device_change','detail'=>"Transaction from unrecognised device: $deviceId"];
        }
        return ['score'=>$score, 'flag'=>$flag];
    }

    // ─────────────────────────────────────────────────────
    // SAVE ALERTS for flagged/blocked transactions
    // ─────────────────────────────────────────────────────
    public function saveAlerts(int $txnId, int $userId, array $result): void {
        foreach ($result['flags'] as $flag) {
            $stmt = $this->db->prepare("
                INSERT INTO fraud_alerts (txn_id, user_id, alert_type, severity, description)
                VALUES (?, ?, ?, ?, ?)
            ");
            $stmt->execute([
                $txnId,
                $userId,
                $flag['type'],
                $result['severity'],
                $flag['detail']
            ]);
        }
        // Notify user
        if ($result['action'] !== 'allow') {
            $msg = $result['action'] === 'block'
                ? 'Your transaction was BLOCKED due to high fraud risk (score: ' . $result['score'] . '/100).'
                : 'A suspicious transaction was flagged on your account. Please review.';
            $stmt = $this->db->prepare("
                INSERT INTO notifications (user_id, title, message, type) VALUES (?, ?, ?, ?)
            ");
            $stmt->execute([$userId, 'Fraud Alert', $msg,
                $result['action'] === 'block' ? 'warning' : 'alert']);
        }
    }
}
