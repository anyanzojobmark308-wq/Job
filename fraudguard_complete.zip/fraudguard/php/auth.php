<?php
// ============================================================
//  FraudGuard – Authentication Handler (auth.php)
//  Place in /fraudguard/php/auth.php
// ============================================================
require_once __DIR__ . '/config.php';
startSession();

$action = $_POST['action'] ?? $_GET['action'] ?? '';

// ─── REGISTER ──────────────────────────────────────────────
if ($action === 'register') {
    $fullName = sanitize($_POST['full_name'] ?? '');
    $email    = filter_var($_POST['email'] ?? '', FILTER_SANITIZE_EMAIL);
    $phone    = sanitize($_POST['phone'] ?? '');
    $password = $_POST['password'] ?? '';

    if (!$fullName || !$email || !$phone || strlen($password) < 6) {
        $_SESSION['error'] = 'All fields are required. Password must be at least 6 characters.';
        header('Location: ../index.php?page=register');
        exit;
    }

    $db = getDB();
    $check = $db->prepare("SELECT user_id FROM users WHERE email = ?");
    $check->execute([$email]);
    if ($check->fetch()) {
        $_SESSION['error'] = 'Email already registered.';
        header('Location: ../index.php?page=register');
        exit;
    }

    $hash   = password_hash($password, PASSWORD_BCRYPT);
    $accNo  = 'FG-' . date('Y') . '-' . strtoupper(substr(uniqid(), -4));
    $stmt   = $db->prepare("INSERT INTO users (full_name, email, phone, password_hash, account_no, balance) VALUES (?,?,?,?,?,0)");
    $stmt->execute([$fullName, $email, $phone, $hash, $accNo]);

    $_SESSION['success'] = 'Registration successful! Please log in.';
    header('Location: ../index.php');
    exit;
}

// ─── LOGIN ─────────────────────────────────────────────────
if ($action === 'login') {
    $email    = filter_var($_POST['email'] ?? '', FILTER_SANITIZE_EMAIL);
    $password = $_POST['password'] ?? '';

    if (!$email || !$password) {
        $_SESSION['error'] = 'Email and password are required.';
        header('Location: ../index.php');
        exit;
    }

    $db   = getDB();
    $stmt = $db->prepare("SELECT * FROM users WHERE email = ? AND status != 'locked'");
    $stmt->execute([$email]);
    $user = $stmt->fetch();

    if (!$user || !password_verify($password, $user['password_hash'])) {
        $_SESSION['error'] = 'Invalid credentials or account locked.';
        header('Location: ../index.php');
        exit;
    }

    // Set session
    $_SESSION['user_id']   = $user['user_id'];
    $_SESSION['full_name'] = $user['full_name'];
    $_SESSION['email']     = $user['email'];
    $_SESSION['role']      = $user['role'];
    $_SESSION['account_no']= $user['account_no'];

    // Update last login
    $db->prepare("UPDATE users SET last_login = NOW() WHERE user_id = ?")->execute([$user['user_id']]);
    logAudit($user['user_id'], 'User login', 'auth');

    // Redirect based on role
    if (in_array($user['role'], ['admin','fraud_officer'])) {
        header('Location: ../admin_dashboard.php');
    } else {
        header('Location: ../dashboard.php');
    }
    exit;
}

// ─── LOGOUT ────────────────────────────────────────────────
if ($action === 'logout') {
    if (isLoggedIn()) {
        logAudit($_SESSION['user_id'], 'User logout', 'auth');
    }
    session_destroy();
    header('Location: ../index.php');
    exit;
}

header('Location: ../index.php');
exit;
