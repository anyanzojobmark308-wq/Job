<?php
// ============================================================
//  FraudGuard – Transaction Handler (transaction.php)
// ============================================================
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/fraud_engine.php';
startSession();
requireLogin();

$action = $_POST['action'] ?? '';
$user   = currentUser();
$db     = getDB();

// ─── MAKE TRANSFER ─────────────────────────────────────────
if ($action === 'transfer') {
    $receiverAcc = sanitize($_POST['receiver_acc'] ?? '');
    $amount      = (float)($_POST['amount'] ?? 0);
    $channel     = sanitize($_POST['channel'] ?? 'mobile_money');
    $deviceId    = sanitize($_POST['device_id'] ?? 'WEB-' . substr(md5($_SERVER['HTTP_USER_AGENT'] ?? ''), 0, 8));
    $ip          = $_SERVER['REMOTE_ADDR'] ?? '0.0.0.0';
    $location    = sanitize($_POST['location'] ?? 'Unknown');

    if ($amount <= 0) {
        echo json_encode(['success'=>false,'message'=>'Invalid amount.']); exit;
    }

    // Lookup receiver
    $recStmt = $db->prepare("SELECT user_id, full_name FROM users WHERE account_no = ? AND status = 'active'");
    $recStmt->execute([$receiverAcc]);
    $receiver = $recStmt->fetch();
    if (!$receiver) {
        echo json_encode(['success'=>false,'message'=>'Receiver account not found or inactive.']); exit;
    }

    // Check sender balance
    $balStmt = $db->prepare("SELECT balance FROM users WHERE user_id = ?");
    $balStmt->execute([$user['user_id']]);
    $balance = (float)$balStmt->fetchColumn();
    if ($balance < $amount) {
        echo json_encode(['success'=>false,'message'=>'Insufficient balance.']); exit;
    }

    // ── Run fraud detection ──────────────────────────────
    $detector = new FraudDetector();
    $fraudResult = $detector->evaluate([
        'sender_id' => $user['user_id'],
        'amount'    => $amount,
        'location'  => $location,
        'ip_address'=> $ip,
        'device_id' => $deviceId,
    ]);

    // Determine transaction status
    $txnStatus = 'pending';
    if ($fraudResult['action'] === 'block')      $txnStatus = 'blocked';
    elseif ($fraudResult['action'] === 'flag')   $txnStatus = 'flagged';
    elseif ($fraudResult['action'] === 'allow')  $txnStatus = 'completed';
    elseif ($fraudResult['action'] === 'alert')  $txnStatus = 'completed'; // alert but allow

    $ref = generateRef('TXN');

    // Insert transaction
    $txnStmt = $db->prepare("
        INSERT INTO transactions
          (sender_id, receiver_id, txn_reference, txn_type, amount, channel,
           device_id, ip_address, location, status, fraud_score)
        VALUES (?,?,?,?,?,?,?,?,?,?,?)
    ");
    $txnStmt->execute([
        $user['user_id'], $receiver['user_id'], $ref, 'transfer',
        $amount, $channel, $deviceId, $ip, $location,
        $txnStatus, $fraudResult['score']
    ]);
    $txnId = (int)$db->lastInsertId();

    // Save fraud alerts
    if (!empty($fraudResult['flags'])) {
        $detector->saveAlerts($txnId, $user['user_id'], $fraudResult);
    }

    // Debit / credit only if completed
    if ($txnStatus === 'completed') {
        $db->prepare("UPDATE users SET balance = balance - ? WHERE user_id = ?")->execute([$amount, $user['user_id']]);
        $db->prepare("UPDATE users SET balance = balance + ? WHERE user_id = ?")->execute([$amount, $receiver['user_id']]);
    }

    logAudit($user['user_id'], "Transfer $ref – $txnStatus (score:{$fraudResult['score']})", 'transaction');

    $msg = match($txnStatus) {
        'blocked'  => "Transaction BLOCKED: High fraud risk detected (score: {$fraudResult['score']}/100). Flags: " . implode(', ', array_column($fraudResult['flags'],'detail')),
        'flagged'  => "Transaction flagged for review (score: {$fraudResult['score']}/100). Funds held pending investigation.",
        default    => "Transfer of " . formatUGX($amount) . " to {$receiver['full_name']} completed successfully."
    };

    echo json_encode([
        'success'     => $txnStatus !== 'blocked',
        'message'     => $msg,
        'status'      => $txnStatus,
        'fraud_score' => $fraudResult['score'],
        'reference'   => $ref,
    ]);
    exit;
}

// ─── GET USER TRANSACTIONS ────────────────────────────────
if ($action === 'get_transactions') {
    $userId = $user['user_id'];
    $stmt   = $db->prepare("
        SELECT t.*, u.full_name as receiver_name
        FROM transactions t
        LEFT JOIN users u ON t.receiver_id = u.user_id
        WHERE t.sender_id = ? OR t.receiver_id = ?
        ORDER BY t.created_at DESC LIMIT 50
    ");
    $stmt->execute([$userId, $userId]);
    echo json_encode(['success'=>true,'data'=>$stmt->fetchAll()]);
    exit;
}

// ─── ADMIN: ALL TRANSACTIONS ──────────────────────────────
if ($action === 'admin_transactions' && isAdmin()) {
    $stmt = $db->prepare("
        SELECT t.*,
               s.full_name as sender_name, s.account_no as sender_acc,
               r.full_name as receiver_name, r.account_no as receiver_acc
        FROM transactions t
        LEFT JOIN users s ON t.sender_id   = s.user_id
        LEFT JOIN users r ON t.receiver_id = r.user_id
        ORDER BY t.created_at DESC LIMIT 200
    ");
    $stmt->execute();
    echo json_encode(['success'=>true,'data'=>$stmt->fetchAll()]);
    exit;
}

echo json_encode(['success'=>false,'message'=>'Invalid action.']);
