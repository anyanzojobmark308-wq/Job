<?php
// ============================================================
//  FraudGuard – Refund & Dispute Handler (refund.php)
// ============================================================
require_once __DIR__ . '/config.php';
startSession();
requireLogin();

$action = $_POST['action'] ?? $_GET['action'] ?? '';
$user   = currentUser();
$db     = getDB();

// ─── SUBMIT REFUND CASE ────────────────────────────────────
if ($action === 'submit_case') {
    $txnRef      = sanitize($_POST['txn_reference'] ?? '');
    $fraudType   = sanitize($_POST['fraud_type'] ?? '');
    $description = sanitize($_POST['description'] ?? '');
    $amountClaimed = (float)($_POST['amount_claimed'] ?? 0);

    if (!$txnRef || !$fraudType || !$description || $amountClaimed <= 0) {
        echo json_encode(['success'=>false,'message'=>'All fields are required.']); exit;
    }

    // Verify transaction belongs to user
    $txnStmt = $db->prepare("SELECT txn_id, amount FROM transactions WHERE txn_reference = ? AND sender_id = ?");
    $txnStmt->execute([$txnRef, $user['user_id']]);
    $txn = $txnStmt->fetch();
    if (!$txn) {
        echo json_encode(['success'=>false,'message'=>'Transaction not found or not linked to your account.']); exit;
    }

    // Check no duplicate case
    $dupCheck = $db->prepare("SELECT case_id FROM refund_cases WHERE txn_id = ? AND complainant_id = ?");
    $dupCheck->execute([$txn['txn_id'], $user['user_id']]);
    if ($dupCheck->fetch()) {
        echo json_encode(['success'=>false,'message'=>'A refund case already exists for this transaction.']); exit;
    }

    $caseRef  = generateRef('CASE');
    $priority = $amountClaimed >= 5000000 ? 'high' : ($amountClaimed >= 1000000 ? 'medium' : 'low');

    $stmt = $db->prepare("
        INSERT INTO refund_cases
          (txn_id, complainant_id, case_reference, fraud_type, description, amount_claimed, priority)
        VALUES (?,?,?,?,?,?,?)
    ");
    $stmt->execute([$txn['txn_id'], $user['user_id'], $caseRef, $fraudType, $description, $amountClaimed, $priority]);

    // Notify admins
    $admins = $db->query("SELECT user_id FROM users WHERE role IN ('admin','fraud_officer')")->fetchAll();
    foreach ($admins as $admin) {
        $notifStmt = $db->prepare("INSERT INTO notifications (user_id,title,message,type) VALUES (?,?,?,?)");
        $notifStmt->execute([$admin['user_id'], 'New Refund Case',
            "Case $caseRef submitted by {$user['full_name']} for " . formatUGX($amountClaimed), 'info']);
    }

    logAudit($user['user_id'], "Refund case $caseRef submitted", 'refund');

    echo json_encode(['success'=>true,'message'=>"Case submitted successfully. Reference: $caseRef",
        'case_reference'=>$caseRef]);
    exit;
}

// ─── GET USER CASES ────────────────────────────────────────
if ($action === 'get_my_cases') {
    $stmt = $db->prepare("
        SELECT rc.*, t.txn_reference, t.amount as txn_amount
        FROM refund_cases rc
        JOIN transactions t ON rc.txn_id = t.txn_id
        WHERE rc.complainant_id = ?
        ORDER BY rc.submitted_at DESC
    ");
    $stmt->execute([$user['user_id']]);
    echo json_encode(['success'=>true,'data'=>$stmt->fetchAll()]);
    exit;
}

// ─── ADMIN: GET ALL CASES ─────────────────────────────────
if ($action === 'admin_get_cases' && isAdmin()) {
    $stmt = $db->query("
        SELECT rc.*, t.txn_reference, t.amount as txn_amount,
               u.full_name as complainant_name, u.email as complainant_email,
               u.phone as complainant_phone
        FROM refund_cases rc
        JOIN transactions t ON rc.txn_id = t.txn_id
        JOIN users u ON rc.complainant_id = u.user_id
        ORDER BY rc.submitted_at DESC
    ");
    echo json_encode(['success'=>true,'data'=>$stmt->fetchAll()]);
    exit;
}

// ─── ADMIN: UPDATE CASE STATUS ────────────────────────────
if ($action === 'update_case' && isAdmin()) {
    $caseId        = (int)($_POST['case_id'] ?? 0);
    $status        = sanitize($_POST['status'] ?? '');
    $amountApproved= (float)($_POST['amount_approved'] ?? 0);
    $adminNotes    = sanitize($_POST['admin_notes'] ?? '');

    $allowed = ['under_review','approved','rejected','refunded'];
    if (!in_array($status, $allowed)) {
        echo json_encode(['success'=>false,'message'=>'Invalid status.']); exit;
    }

    $resolved = in_array($status, ['approved','rejected','refunded']) ? 'NOW()' : 'NULL';

    $db->prepare("
        UPDATE refund_cases
        SET status = ?, amount_approved = ?, admin_notes = ?,
            assigned_to = ?, resolved_at = $resolved
        WHERE case_id = ?
    ")->execute([$status, $amountApproved, $adminNotes, $user['user_id'], $caseId]);

    // Notify complainant
    $caseInfo = $db->prepare("SELECT complainant_id, case_reference FROM refund_cases WHERE case_id = ?");
    $caseInfo->execute([$caseId]);
    $c = $caseInfo->fetch();
    if ($c) {
        $notifMsg = match($status) {
            'approved'  => "Your refund case {$c['case_reference']} has been APPROVED. Amount: " . formatUGX($amountApproved),
            'rejected'  => "Your refund case {$c['case_reference']} has been REJECTED. Notes: $adminNotes",
            'refunded'  => "Your refund of " . formatUGX($amountApproved) . " has been processed for case {$c['case_reference']}.",
            default     => "Your refund case {$c['case_reference']} is now under review.",
        };
        $type = in_array($status, ['approved','refunded']) ? 'success' : 'info';
        $db->prepare("INSERT INTO notifications (user_id,title,message,type) VALUES (?,?,?,?)")
           ->execute([$c['complainant_id'], 'Case Update', $notifMsg, $type]);

        // If refunded, credit the user
        if ($status === 'refunded' && $amountApproved > 0) {
            $db->prepare("UPDATE users SET balance = balance + ? WHERE user_id = ?")
               ->execute([$amountApproved, $c['complainant_id']]);
        }
    }

    logAudit($user['user_id'], "Case $caseId updated to $status", 'refund');
    echo json_encode(['success'=>true,'message'=>"Case updated to '$status' successfully."]);
    exit;
}

echo json_encode(['success'=>false,'message'=>'Invalid or unauthorized action.']);
