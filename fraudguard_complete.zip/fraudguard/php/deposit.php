<?php
// ============================================================
//  FraudGuard – Deposit Handler (deposit.php)
// ============================================================
require_once __DIR__ . '/config.php';
startSession();
requireLogin();

$action = $_POST['action'] ?? $_GET['action'] ?? '';
$user   = currentUser();
$db     = getDB();

// ─── CUSTOMER: Submit deposit request ─────────────────────
if ($action === 'request_deposit') {
    $amount  = (float)($_POST['amount'] ?? 0);
    $method  = sanitize($_POST['method'] ?? '');
    $ref     = sanitize($_POST['payment_ref'] ?? '');
    $notes   = sanitize($_POST['notes'] ?? '');

    if ($amount < 1000) {
        echo json_encode(['success'=>false,'message'=>'Minimum deposit is UGX 1,000.']); exit;
    }
    if (!$method) {
        echo json_encode(['success'=>false,'message'=>'Please select a payment method.']); exit;
    }

    $depRef  = generateRef('DEP');
    $stmt    = $db->prepare("
        INSERT INTO deposit_requests
          (user_id, deposit_reference, amount, payment_method, payment_ref, notes, status)
        VALUES (?,?,?,?,?,?,?)
    ");
    $stmt->execute([
        $user['user_id'], $depRef, $amount, $method, $ref, $notes, 'pending'
    ]);
    $depId = (int)$db->lastInsertId();

    // Notify admins
    $admins = $db->query("SELECT user_id FROM users WHERE role IN ('admin','fraud_officer')")->fetchAll();
    foreach ($admins as $admin) {
        $db->prepare("INSERT INTO notifications (user_id,title,message,type) VALUES (?,?,?,?)")
           ->execute([$admin['user_id'], 'New Deposit Request',
               "{$user['full_name']} requested a deposit of " . formatUGX($amount) . " via $method. Ref: $depRef", 'info']);
    }

    logAudit($user['user_id'], "Deposit request $depRef – " . formatUGX($amount), 'deposit');

    echo json_encode([
        'success'   => true,
        'message'   => "Deposit request submitted! Reference: $depRef. Wait for admin approval.",
        'reference' => $depRef
    ]);
    exit;
}

// ─── CUSTOMER: Get my deposit requests ────────────────────
if ($action === 'my_deposits') {
    $stmt = $db->prepare("SELECT * FROM deposit_requests WHERE user_id=? ORDER BY created_at DESC");
    $stmt->execute([$user['user_id']]);
    echo json_encode(['success'=>true,'data'=>$stmt->fetchAll()]);
    exit;
}

// ─── ADMIN: Get all deposit requests ──────────────────────
if ($action === 'admin_get_deposits' && isAdmin()) {
    $stmt = $db->query("
        SELECT dr.*, u.full_name, u.email, u.phone, u.account_no
        FROM deposit_requests dr
        JOIN users u ON dr.user_id = u.user_id
        ORDER BY dr.created_at DESC
    ");
    echo json_encode(['success'=>true,'data'=>$stmt->fetchAll()]);
    exit;
}

// ─── ADMIN: Approve deposit ───────────────────────────────
if ($action === 'approve_deposit' && isAdmin()) {
    $depId          = (int)($_POST['deposit_id'] ?? 0);
    $amountApproved = (float)($_POST['amount_approved'] ?? 0);
    $adminNotes     = sanitize($_POST['admin_notes'] ?? '');

    if (!$depId || $amountApproved <= 0) {
        echo json_encode(['success'=>false,'message'=>'Invalid deposit or amount.']); exit;
    }

    // Get deposit info
    $depStmt = $db->prepare("SELECT * FROM deposit_requests WHERE deposit_id=? AND status='pending'");
    $depStmt->execute([$depId]);
    $dep = $depStmt->fetch();
    if (!$dep) {
        echo json_encode(['success'=>false,'message'=>'Deposit not found or already processed.']); exit;
    }

    // Update deposit status
    $db->prepare("
        UPDATE deposit_requests
        SET status='approved', amount_approved=?, admin_notes=?, approved_by=?, approved_at=NOW()
        WHERE deposit_id=?
    ")->execute([$amountApproved, $adminNotes, $user['user_id'], $depId]);

    // Credit user balance
    $db->prepare("UPDATE users SET balance = balance + ? WHERE user_id=?")
       ->execute([$amountApproved, $dep['user_id']]);

    // Record as a transaction
    $txnRef = generateRef('TXN');
    $db->prepare("
        INSERT INTO transactions
          (sender_id, receiver_id, txn_reference, txn_type, amount, channel, status, fraud_score)
        VALUES (?,?,?,'deposit',?,'online_banking','completed',0)
    ")->execute([$dep['user_id'], $dep['user_id'], $txnRef, $amountApproved]);

    // Notify user
    $db->prepare("INSERT INTO notifications (user_id,title,message,type) VALUES (?,?,?,?)")
       ->execute([$dep['user_id'], 'Deposit Approved! ✅',
           "Your deposit of " . formatUGX($amountApproved) . " (Ref: {$dep['deposit_reference']}) has been approved and credited to your account.",
           'success']);

    logAudit($user['user_id'], "Deposit {$dep['deposit_reference']} approved – " . formatUGX($amountApproved), 'deposit');

    echo json_encode(['success'=>true,'message'=>"Deposit approved and UGX " . number_format($amountApproved,0) . " credited to user's account."]);
    exit;
}

// ─── ADMIN: Reject deposit ────────────────────────────────
if ($action === 'reject_deposit' && isAdmin()) {
    $depId      = (int)($_POST['deposit_id'] ?? 0);
    $adminNotes = sanitize($_POST['admin_notes'] ?? '');

    $depStmt = $db->prepare("SELECT * FROM deposit_requests WHERE deposit_id=? AND status='pending'");
    $depStmt->execute([$depId]);
    $dep = $depStmt->fetch();
    if (!$dep) {
        echo json_encode(['success'=>false,'message'=>'Deposit not found or already processed.']); exit;
    }

    $db->prepare("
        UPDATE deposit_requests
        SET status='rejected', admin_notes=?, approved_by=?, approved_at=NOW()
        WHERE deposit_id=?
    ")->execute([$adminNotes, $user['user_id'], $depId]);

    // Notify user
    $db->prepare("INSERT INTO notifications (user_id,title,message,type) VALUES (?,?,?,?)")
       ->execute([$dep['user_id'], 'Deposit Rejected',
           "Your deposit request (Ref: {$dep['deposit_reference']}) was rejected. Reason: $adminNotes",
           'warning']);

    logAudit($user['user_id'], "Deposit {$dep['deposit_reference']} rejected", 'deposit');

    echo json_encode(['success'=>true,'message'=>'Deposit request rejected.']);
    exit;
}

echo json_encode(['success'=>false,'message'=>'Invalid action.']);
