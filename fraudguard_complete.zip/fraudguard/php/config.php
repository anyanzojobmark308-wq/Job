<?php
// ============================================================
//  FraudGuard – Database Configuration
// ============================================================
define('DB_HOST', 'localhost');
define('DB_USER', 'root');        // Change to your MySQL username
define('DB_PASS', '');            // Change to your MySQL password
define('DB_NAME', 'fraudguard_db');
define('SITE_NAME', 'FraudGuard');
define('SITE_URL',  'http://localhost/fraudguard');

// ─── PDO Connection ───────────────────────────────────────
function getDB(): PDO {
    static $pdo = null;
    if ($pdo === null) {
        try {
            $dsn = "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=utf8mb4";
            $pdo = new PDO($dsn, DB_USER, DB_PASS, [
                PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                PDO::ATTR_EMULATE_PREPARES   => false,
            ]);
        } catch (PDOException $e) {
            die(json_encode(['error' => 'Database connection failed: ' . $e->getMessage()]));
        }
    }
    return $pdo;
}

// ─── Session helper ───────────────────────────────────────
function startSession(): void {
    if (session_status() === PHP_SESSION_NONE) {
        session_start();
    }
}

// ─── Auth helpers ─────────────────────────────────────────
function isLoggedIn(): bool {
    startSession();
    return isset($_SESSION['user_id']);
}

function requireLogin(): void {
    if (!isLoggedIn()) {
        header('Location: index.php');
        exit;
    }
}

function isAdmin(): bool {
    startSession();
    return isset($_SESSION['role']) && in_array($_SESSION['role'], ['admin', 'fraud_officer']);
}

function currentUser(): array {
    startSession();
    return [
        'user_id'   => $_SESSION['user_id']   ?? null,
        'full_name' => $_SESSION['full_name'] ?? '',
        'role'      => $_SESSION['role']      ?? 'customer',
        'email'     => $_SESSION['email']     ?? '',
    ];
}

// ─── Utility ──────────────────────────────────────────────
function sanitize(string $input): string {
    return htmlspecialchars(strip_tags(trim($input)), ENT_QUOTES, 'UTF-8');
}

function formatUGX(float $amount): string {
    return 'UGX ' . number_format($amount, 0);
}

function generateRef(string $prefix = 'TXN'): string {
    return $prefix . '-' . date('Y') . '-' . strtoupper(substr(uniqid(), -6));
}

function logAudit(int $userId, string $action, string $module = '', string $details = ''): void {
    $db = getDB();
    $ip = $_SERVER['REMOTE_ADDR'] ?? 'unknown';
    $stmt = $db->prepare("INSERT INTO audit_logs (user_id, action, module, ip_address, details) VALUES (?,?,?,?,?)");
    $stmt->execute([$userId, $action, $module, $ip, $details]);
}
