<?php
// ============================================================
//  FraudGuard – Admin Users Management
// ============================================================
require_once 'php/config.php';
startSession(); requireLogin();
if (!isAdmin()) { header('Location: dashboard.php'); exit; }
$user = currentUser();
$db   = getDB();

// Handle suspend/activate via POST
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $uid    = (int)($_POST['uid'] ?? 0);
    $action = sanitize($_POST['action'] ?? '');
    if ($uid && in_array($action, ['suspend','activate','lock'])) {
        $map = ['suspend'=>'suspended','activate'=>'active','lock'=>'locked'];
        $db->prepare("UPDATE users SET status=? WHERE user_id=?")->execute([$map[$action], $uid]);
        logAudit($user['user_id'], "User $uid status changed to {$map[$action]}", 'users');
    }
    header('Location: admin_users.php'); exit;
}

$users = $db->query("SELECT user_id,full_name,email,phone,role,account_no,balance,status,created_at,last_login FROM users ORDER BY created_at DESC")->fetchAll();
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Users – FraudGuard Admin</title>
<link href="https://fonts.googleapis.com/css2?family=Space+Grotesk:wght@300;400;500;600;700&family=Syne:wght@700;800&display=swap" rel="stylesheet">
<link rel="stylesheet" href="css/style.css">
</head>
<body>
<div class="app-layout">
  <aside class="sidebar">
    <div class="sidebar-brand"><div class="icon">🛡️</div><div class="name">Fraud<span>Guard</span></div></div>
    <div class="sidebar-user">
      <div class="avatar" style="background:linear-gradient(135deg,#ff6b35,#ff4444)"><?= strtoupper(substr($user['full_name'],0,1)) ?></div>
      <div class="uname"><?= htmlspecialchars($user['full_name']) ?></div>
      <div class="urole" style="color:var(--danger)"><?= ucfirst(str_replace('_',' ',$user['role'])) ?></div>
    </div>
    <nav class="sidebar-nav">
      <a href="admin_dashboard.php" class="nav-link"><span class="icon">📊</span> Dashboard</a>
      <a href="transactions.php" class="nav-link"><span class="icon">💳</span> Transactions</a>
      <a href="admin_alerts.php" class="nav-link"><span class="icon">⚠️</span> Fraud Alerts</a>
      <a href="admin_cases.php" class="nav-link"><span class="icon">📁</span> Refund Cases</a>
      <a href="admin_users.php" class="nav-link active"><span class="icon">👥</span> Users</a>
      <a href="notifications.php" class="nav-link"><span class="icon">🔔</span> Notifications</a>
    </nav>
    <div class="sidebar-footer"><a href="php/auth.php?action=logout" class="nav-link"><span class="icon">🚪</span> Logout</a></div>
  </aside>

  <div class="main-content">
    <div class="topbar">
      <div class="topbar-title">👥 User Management</div>
      <div class="topbar-actions">
        <input type="text" class="form-input" id="search-input" placeholder="Search users..." style="width:220px" oninput="filterUsers()">
      </div>
    </div>

    <div class="page-content">
      <!-- Summary Cards -->
      <div class="stats-grid" style="margin-bottom:24px">
        <?php
          $total    = count($users);
          $active   = count(array_filter($users, fn($u) => $u['status']==='active'));
          $suspended= count(array_filter($users, fn($u) => $u['status']==='suspended'));
          $admins   = count(array_filter($users, fn($u) => in_array($u['role'],['admin','fraud_officer'])));
        ?>
        <div class="stat-card blue"><div class="stat-icon">👥</div><div class="stat-value"><?= $total ?></div><div class="stat-label">Total Users</div></div>
        <div class="stat-card green"><div class="stat-icon">✅</div><div class="stat-value"><?= $active ?></div><div class="stat-label">Active</div></div>
        <div class="stat-card red"><div class="stat-icon">🔒</div><div class="stat-value"><?= $suspended ?></div><div class="stat-label">Suspended</div></div>
        <div class="stat-card purple"><div class="stat-icon">🛡️</div><div class="stat-value"><?= $admins ?></div><div class="stat-label">Admins / Officers</div></div>
      </div>

      <div class="data-card">
        <div class="data-card-header">
          <div class="data-card-title">All Registered Users</div>
          <span id="user-count" style="font-size:13px;color:var(--muted)"><?= $total ?> users</span>
        </div>
        <div style="overflow-x:auto">
          <table class="data-table" id="users-table">
            <thead><tr>
              <th>Name</th><th>Email</th><th>Phone</th><th>Account No</th>
              <th>Balance</th><th>Role</th><th>Status</th><th>Last Login</th><th>Actions</th>
            </tr></thead>
            <tbody>
              <?php foreach($users as $u): ?>
              <tr class="user-row" data-search="<?= strtolower($u['full_name'].' '.$u['email'].' '.$u['phone']) ?>">
                <td><strong><?= htmlspecialchars($u['full_name']) ?></strong></td>
                <td style="color:var(--accent)"><?= htmlspecialchars($u['email']) ?></td>
                <td><?= htmlspecialchars($u['phone']) ?></td>
                <td style="font-family:monospace;font-size:12px"><?= htmlspecialchars($u['account_no'] ?? '—') ?></td>
                <td style="font-weight:600">UGX <?= number_format($u['balance'],0) ?></td>
                <td><span class="badge badge-<?= $u['role']==='customer'?'completed':'flagged' ?>"><?= ucfirst(str_replace('_',' ',$u['role'])) ?></span></td>
                <td>
                  <span class="badge badge-<?= $u['status']==='active'?'completed':($u['status']==='suspended'?'flagged':'blocked') ?>">
                    <?= ucfirst($u['status']) ?>
                  </span>
                </td>
                <td style="font-size:12px;color:var(--muted)"><?= $u['last_login'] ? date('d M Y H:i', strtotime($u['last_login'])) : 'Never' ?></td>
                <td>
                  <?php if ($u['user_id'] != $user['user_id']): ?>
                  <div style="display:flex;gap:6px">
                    <?php if ($u['status'] !== 'active'): ?>
                      <form method="POST" style="display:inline">
                        <input type="hidden" name="uid" value="<?= $u['user_id'] ?>">
                        <input type="hidden" name="action" value="activate">
                        <button type="submit" class="btn btn-success btn-xs">Activate</button>
                      </form>
                    <?php else: ?>
                      <form method="POST" style="display:inline">
                        <input type="hidden" name="uid" value="<?= $u['user_id'] ?>">
                        <input type="hidden" name="action" value="suspend">
                        <button type="submit" class="btn btn-danger btn-xs">Suspend</button>
                      </form>
                    <?php endif; ?>
                    <form method="POST" style="display:inline" onsubmit="return confirm('Lock this account?')">
                      <input type="hidden" name="uid" value="<?= $u['user_id'] ?>">
                      <input type="hidden" name="action" value="lock">
                      <button type="submit" class="btn btn-secondary btn-xs">Lock</button>
                    </form>
                  </div>
                  <?php else: ?>
                  <span style="font-size:12px;color:var(--muted)">You</span>
                  <?php endif; ?>
                </td>
              </tr>
              <?php endforeach; ?>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  </div>
</div>

<script>
function filterUsers() {
  const q     = document.getElementById('search-input').value.toLowerCase();
  const rows  = document.querySelectorAll('.user-row');
  let visible = 0;
  rows.forEach(r => {
    const show = r.dataset.search.includes(q);
    r.style.display = show ? '' : 'none';
    if (show) visible++;
  });
  document.getElementById('user-count').textContent = visible + ' users';
}
</script>
</body>
</html>
