<?php
// ============================================================
//  FraudGuard – Transactions Page (transactions.php)
// ============================================================
require_once 'php/config.php';
startSession(); requireLogin();
$user = currentUser();
$isAdmin = isAdmin();
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Transactions – FraudGuard</title>
<link href="https://fonts.googleapis.com/css2?family=Space+Grotesk:wght@300;400;500;600;700&family=Syne:wght@700;800&display=swap" rel="stylesheet">
<link rel="stylesheet" href="css/style.css">
</head>
<body>
<div class="app-layout">
  <aside class="sidebar">
    <div class="sidebar-brand"><div class="icon">🛡️</div><div class="name">Fraud<span>Guard</span></div></div>
    <div class="sidebar-user">
      <div class="avatar"><?= strtoupper(substr($user['full_name'],0,1)) ?></div>
      <div class="uname"><?= htmlspecialchars($user['full_name']) ?></div>
      <div class="urole"><?= ucfirst(str_replace('_',' ',$user['role'])) ?></div>
    </div>
    <nav class="sidebar-nav">
      <?php if ($isAdmin): ?>
      <a href="admin_dashboard.php" class="nav-link"><span class="icon">📊</span> Dashboard</a>
      <a href="admin_transactions.php" class="nav-link active"><span class="icon">💳</span> All Transactions</a>
      <a href="admin_alerts.php" class="nav-link"><span class="icon">⚠️</span> Fraud Alerts</a>
      <a href="admin_cases.php" class="nav-link"><span class="icon">📁</span> Refund Cases</a>
      <?php else: ?>
      <a href="dashboard.php" class="nav-link"><span class="icon">📊</span> Dashboard</a>
      <a href="transactions.php" class="nav-link active"><span class="icon">📋</span> Transactions</a>
      <a href="refunds.php" class="nav-link"><span class="icon">🔄</span> My Refund Cases</a>
      <a href="notifications.php" class="nav-link"><span class="icon">🔔</span> Notifications</a>
      <?php endif; ?>
    </nav>
    <div class="sidebar-footer"><a href="php/auth.php?action=logout" class="nav-link"><span class="icon">🚪</span> Logout</a></div>
  </aside>

  <div class="main-content">
    <div class="topbar">
      <div class="topbar-title"><?= $isAdmin ? 'All Transactions' : 'My Transactions' ?></div>
      <div class="topbar-actions">
        <select class="form-select" id="filter-status" style="width:150px" onchange="applyFilter()">
          <option value="">All</option>
          <option value="completed">Completed</option>
          <option value="flagged">Flagged</option>
          <option value="blocked">Blocked</option>
          <option value="pending">Pending</option>
          <option value="refunded">Refunded</option>
        </select>
        <?php if (!$isAdmin): ?>
        <button class="btn btn-primary btn-sm" onclick="openModal('transferModal')">+ New Transfer</button>
        <?php endif; ?>
      </div>
    </div>

    <div class="page-content">
      <div id="toast-container"></div>
      <div class="data-card">
        <div class="data-card-header">
          <div class="data-card-title">💳 Transaction History</div>
          <span id="txn-count" style="font-size:13px;color:var(--muted)"></span>
        </div>
        <div style="overflow-x:auto">
          <table class="data-table">
            <thead><tr>
              <th>Reference</th>
              <?php if ($isAdmin): ?><th>Sender</th><th>Receiver</th><?php else: ?><th>Type</th><th>Receiver</th><?php endif; ?>
              <th>Amount</th><th>Channel</th><th>Location</th>
              <th>Fraud Score</th><th>Status</th><th>Date</th>
            </tr></thead>
            <tbody id="txn-body">
              <tr><td colspan="10" style="text-align:center;color:var(--muted);padding:30px">Loading...</td></tr>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  </div>
</div>

<!-- Transfer Modal (customer only) -->
<?php if (!$isAdmin): ?>
<div class="modal-overlay" id="transferModal">
  <div class="modal">
    <div style="display:flex;justify-content:space-between;align-items:start;margin-bottom:20px">
      <div><div class="modal-title">💸 New Transfer</div><div class="modal-sub">Fraud-protected money transfer</div></div>
      <button onclick="closeModal('transferModal')" style="background:none;border:none;color:var(--muted);font-size:22px;cursor:pointer">×</button>
    </div>
    <div id="transfer-alert"></div>
    <div class="form-group"><label class="form-label">Receiver Account No.</label><input type="text" class="form-input" id="receiver-acc" placeholder="FG-2025-XXXX"></div>
    <div class="form-group"><label class="form-label">Amount (UGX)</label><input type="number" class="form-input" id="transfer-amount" min="100"></div>
    <div class="form-group"><label class="form-label">Channel</label>
      <select class="form-select" id="transfer-channel">
        <option value="mobile_money">Mobile Money</option>
        <option value="online_banking">Online Banking</option>
        <option value="agent">Agent</option>
      </select>
    </div>
    <div class="form-group"><label class="form-label">Location</label><input type="text" class="form-input" id="transfer-location" placeholder="Kampala, UG"></div>
    <div style="display:flex;gap:12px">
      <button class="btn btn-secondary" onclick="closeModal('transferModal')" style="flex:1">Cancel</button>
      <button class="btn btn-primary" onclick="submitTransfer()" style="flex:1" id="transfer-btn">Send →</button>
    </div>
  </div>
</div>
<?php endif; ?>

<script>
let allTxns = [];
const IS_ADMIN = <?= $isAdmin ? 'true' : 'false' ?>;

function openModal(id)  { document.getElementById(id).classList.add('open'); }
function closeModal(id) { document.getElementById(id).classList.remove('open'); }
function fmtUGX(n) { return 'UGX ' + Number(n).toLocaleString(); }
function fmtDate(s) { return new Date(s).toLocaleString('en-UG',{day:'2-digit',month:'short',year:'numeric',hour:'2-digit',minute:'2-digit'}); }
function scoreClass(s) {
  s = parseFloat(s);
  if (s >= 80) return 'critical';
  if (s >= 60) return 'high';
  if (s >= 35) return 'medium';
  return 'low';
}

async function loadTransactions() {
  const action = IS_ADMIN ? 'admin_transactions' : 'get_transactions';
  const res    = await fetch('php/transaction.php', {
    method: 'POST',
    body: new URLSearchParams({ action })
  });
  const json = await res.json();
  if (!json.success) return;
  allTxns = json.data;
  applyFilter();
}

function applyFilter() {
  const filter = document.getElementById('filter-status').value;
  const txns   = filter ? allTxns.filter(t => t.status === filter) : allTxns;
  document.getElementById('txn-count').textContent = txns.length + ' records';
  const tbody = document.getElementById('txn-body');

  if (!txns.length) {
    tbody.innerHTML = '<tr><td colspan="10" style="text-align:center;color:var(--muted);padding:30px">No transactions found.</td></tr>';
    return;
  }

  tbody.innerHTML = txns.map(t => {
    const sc = parseFloat(t.fraud_score);
    return `<tr>
      <td><span style="font-family:monospace;color:var(--accent);font-size:12px">${t.txn_reference}</span></td>
      ${IS_ADMIN
        ? `<td>${t.sender_name || '—'}<br><span style="font-size:11px;color:var(--muted)">${t.sender_acc || ''}</span></td>
           <td>${t.receiver_name || '—'}</td>`
        : `<td style="text-transform:capitalize">${t.txn_type}</td>
           <td>${t.receiver_name || '—'}</td>`}
      <td style="font-weight:600">${fmtUGX(t.amount)}</td>
      <td style="text-transform:capitalize;font-size:13px">${(t.channel||'').replace('_',' ')}</td>
      <td style="font-size:12px;color:var(--muted)">${t.location || '—'}</td>
      <td>
        <div style="display:flex;align-items:center;gap:8px">
          <span class="score-circle ${scoreClass(sc)}" style="width:36px;height:36px;font-size:11px">${sc}</span>
        </div>
      </td>
      <td><span class="badge badge-${t.status}">${t.status}</span></td>
      <td style="color:var(--muted);font-size:12px">${fmtDate(t.created_at)}</td>
    </tr>`;
  }).join('');
}

async function submitTransfer() {
  const btn = document.getElementById('transfer-btn');
  btn.innerHTML = '<div class="spinner"></div>';
  btn.disabled = true;
  const body = new FormData();
  body.append('action',       'transfer');
  body.append('receiver_acc', document.getElementById('receiver-acc').value);
  body.append('amount',       document.getElementById('transfer-amount').value);
  body.append('channel',      document.getElementById('transfer-channel').value);
  body.append('location',     document.getElementById('transfer-location').value || 'Kampala, UG');
  const res  = await fetch('php/transaction.php', { method:'POST', body });
  const json = await res.json();
  const el   = document.getElementById('transfer-alert');
  if (json.success) {
    el.innerHTML = `<div class="alert alert-success">✅ ${json.message}</div>`;
    setTimeout(() => { closeModal('transferModal'); loadTransactions(); }, 2000);
  } else {
    el.innerHTML = `<div class="alert alert-${json.status === 'blocked' ? 'warning' : 'error'}">⚠️ ${json.message}</div>`;
  }
  btn.innerHTML = 'Send →'; btn.disabled = false;
}

loadTransactions();
</script>
</body>
</html>
