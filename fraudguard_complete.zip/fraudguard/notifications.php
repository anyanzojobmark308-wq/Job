<?php
// ============================================================
//  FraudGuard – Notifications Page
// ============================================================
require_once 'php/config.php';
startSession(); requireLogin();
$user = currentUser();
$isAdmin = isAdmin();
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Notifications – FraudGuard</title>
<link href="https://fonts.googleapis.com/css2?family=Space+Grotesk:wght@300;400;500;600;700&family=Syne:wght@700;800&display=swap" rel="stylesheet">
<link rel="stylesheet" href="css/style.css">
</head>
<body>
<div class="app-layout">
  <aside class="sidebar">
    <div class="sidebar-brand"><div class="icon">🛡️</div><div class="name">Fraud<span>Guard</span></div></div>
    <div class="sidebar-user">
      <div class="avatar"><?= strtoupper(substr($user['full_name'],0,1)) ?></div>
      <div class="uname"><?= htmlspecialchars($user['full_name']) ?></div>
      <div class="urole"><?= ucfirst(str_replace('_',' ',$user['role'])) ?></div>
    </div>
    <nav class="sidebar-nav">
      <?php if ($isAdmin): ?>
      <a href="admin_dashboard.php" class="nav-link"><span class="icon">📊</span> Dashboard</a>
      <a href="admin_transactions.php" class="nav-link"><span class="icon">💳</span> Transactions</a>
      <a href="admin_cases.php" class="nav-link"><span class="icon">📁</span> Refund Cases</a>
      <?php else: ?>
      <a href="dashboard.php" class="nav-link"><span class="icon">📊</span> Dashboard</a>
      <a href="transactions.php" class="nav-link"><span class="icon">📋</span> Transactions</a>
      <a href="refunds.php" class="nav-link"><span class="icon">🔄</span> My Refund Cases</a>
      <?php endif; ?>
      <a href="notifications.php" class="nav-link active"><span class="icon">🔔</span> Notifications</a>
    </nav>
    <div class="sidebar-footer"><a href="php/auth.php?action=logout" class="nav-link"><span class="icon">🚪</span> Logout</a></div>
  </aside>

  <div class="main-content">
    <div class="topbar"><div class="topbar-title">🔔 Notifications</div></div>
    <div class="page-content">
      <div class="data-card" id="notif-card">
        <div class="data-card-header"><div class="data-card-title">All Notifications</div></div>
        <div id="notif-list" style="padding:8px 0">
          <div style="text-align:center;padding:40px;color:var(--muted)">Loading...</div>
        </div>
      </div>
    </div>
  </div>
</div>
<script>
async function loadNotifications() {
  const res  = await fetch('php/analytics.php?action=notifications');
  const json = await res.json();
  if (!json.success) return;
  const list = document.getElementById('notif-list');
  if (!json.data.length) {
    list.innerHTML = '<div class="empty-state"><div class="icon">🔔</div><p>No notifications yet.</p></div>';
    return;
  }
  const icons = { alert:'⚠️', warning:'🔒', success:'✅', info:'ℹ️' };
  list.innerHTML = json.data.map(n => `
    <div style="padding:16px 22px; border-bottom:1px solid var(--border); display:flex; gap:14px; align-items:start; ${!n.is_read ? 'background:rgba(0,212,255,0.03)' : ''}">
      <div style="font-size:22px; margin-top:2px">${icons[n.type]||'ℹ️'}</div>
      <div style="flex:1">
        <div style="font-weight:600; margin-bottom:4px">${n.title}</div>
        <div style="font-size:14px; color:var(--muted); line-height:1.5">${n.message}</div>
        <div style="font-size:12px; color:var(--muted); margin-top:6px">${new Date(n.created_at).toLocaleString('en-UG')}</div>
      </div>
      <span class="badge badge-${n.type}">${n.type}</span>
    </div>
  `).join('');
}
loadNotifications();
</script>
</body>
</html>
